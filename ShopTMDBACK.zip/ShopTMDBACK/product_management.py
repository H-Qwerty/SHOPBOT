from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ParseMode, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

from database import db, format_currency, is_admin
from keyboards import get_product_management_keyboard, get_helper_keyboard, get_admin_keyboard
from states import AdminStates
from utils import safe_html
from config import ADMIN_IDS, HELPER_IDS

# Register handlers
def register_product_handlers(dp, bot):
  # Product Management handler
  @dp.message_handler(Text(equals="📦 Управление товарми"), is_admin_or_helper=True)
  async def product_management(message: types.Message):
      await message.answer(
          safe_html("📦 <b>Управление товарами</b>\n\n"
          "Выберите действие из меню ниже:"),
          reply_markup=get_product_management_keyboard(),
          parse_mode=ParseMode.HTML
      )

  # Back to Helper Panel handler
  @dp.message_handler(Text(equals="🔙 Назад в Админ меню"), is_helper=True)
  async def back_to_helper_panel(message: types.Message):
      await message.answer(
          "🔙 Возврат в панель помощника.",
          reply_markup=get_helper_keyboard()
      )

  # Delete All Categories handler
  @dp.message_handler(Text(equals="🗑️ Удалить все категории"), is_admin_or_helper=True)
  async def delete_all_categories(message: types.Message):
      markup = InlineKeyboardMarkup()
      markup.add(InlineKeyboardButton("✅ Да, удалить все", callback_data="confirm_delete_all_categories"))
      markup.add(InlineKeyboardButton("❌ Нет, отменить", callback_data="cancel_delete_all_categories"))
      
      await message.answer(
          safe_html("🗑️ <b>Удалить все категории</b>\n\n"
          "⚠️ ВНИМАНИЕ: Это удалит ВСЕ категории, позиции и товары. Это действие нельзя отменить.\n\n"
          "Вы уверены, что хотите продолжить?"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.callback_query_handler(lambda c: c.data == "confirm_delete_all_categories", is_admin_callback=True)
  async def confirm_delete_all_categories(callback_query: types.CallbackQuery):
      await bot.answer_callback_query(callback_query.id)
      
      # Clear all categories, positions, and products
      db.categories = {}
      db.positions = {}
      db.products = {}
      db.save()
      
      await bot.send_message(
          callback_query.from_user.id,
          "✅ Все категории, позиции и товары были удалены.",
          reply_markup=get_product_management_keyboard()
      )

  @dp.callback_query_handler(lambda c: c.data == "cancel_delete_all_categories", is_admin_callback=True)
  async def cancel_delete_all_categories(callback_query: types.CallbackQuery):
      await bot.answer_callback_query(callback_query.id)
      await bot.send_message(callback_query.from_user.id, "❌ Операция отменена.", reply_markup=get_product_management_keyboard())

  # Create Category handler
  @dp.message_handler(Text(equals="➕ Создать категорию"), is_admin_or_helper=True)
  async def create_category_start(message: types.Message):
      await AdminStates.create_category.set()
      
      await message.answer(
          safe_html("➕ <b>Создать категорию</b>\n\n"
          "Пожалуйста, введите название для новой категории:"),
          parse_mode=ParseMode.HTML
      )

  @dp.message_handler(state=AdminStates.create_category, is_admin_or_helper=True)
  async def process_category_name(message: types.Message, state: FSMContext):
      category_name = message.text.strip()
      
      if not category_name:
          await message.answer("❌ Название категории не может быть пустым. Пожалуйста, попробуйте снова.")
          return
      
      # Generate a unique category ID
      category_id = f"cat_{len(db.categories) + 1}"
      
      # Create the category
      db.categories[category_id] = {
          "id": category_id,
          "name": category_name,
          "positions": []
      }
      
      db.save()
      
      await message.answer(
          f"✅ Категория '{category_name}' успешно создана.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  # Edit Category handler
  @dp.message_handler(Text(equals="✏️ Редактировать категорию"), is_admin_or_helper=True)
  async def edit_category_start(message: types.Message):
      if not db.categories:
          await message.answer("❌ Нет категорий для редактирования. Пожалуйста, сначала создайте категорию.", reply_markup=get_product_management_keyboard())
          return
      
      await AdminStates.edit_category_select.set()
      
      markup = InlineKeyboardMarkup()
      for category_id, category in db.categories.items():
          markup.add(InlineKeyboardButton(category["name"], callback_data=f"edit_cat_{category_id}"))
      
      await message.answer(
          safe_html("✏️ <b>Редактировать категорию</b>\n\n"
          "Пожалуйста, выберите категорию для редактирования:"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.callback_query_handler(lambda c: c.data.startswith('edit_cat_'), state=AdminStates.edit_category_select)
  async def edit_category_name_start(callback_query: types.CallbackQuery, state: FSMContext):
      await bot.answer_callback_query(callback_query.id)
      
      category_id = callback_query.data.replace("edit_cat_", "")
      
      if category_id not in db.categories:
          await bot.send_message(callback_query.from_user.id, "❌ Категория не найдена.")
          await state.finish()
          return
      
      # Save category ID in state
      await AdminStates.edit_category_name.set()
      await state.update_data(category_id=category_id)
      
      category = db.categories[category_id]
      
      markup = InlineKeyboardMarkup()
      markup.add(InlineKeyboardButton("🗑️ Удалить категорию", callback_data=f"delete_cat_{category_id}"))
      markup.add(InlineKeyboardButton("🔙 Отмена", callback_data="cancel_edit_category"))
      
      await bot.send_message(
          callback_query.from_user.id,
          safe_html(f"✏️ <b>Редактировать категорию</b>\n\n"
          f"Текущее название: {category['name']}\n\n"
          f"Пожалуйста, введите новое название для категории или выберите опцию ниже:"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.message_handler(state=AdminStates.edit_category_name, is_admin_or_helper=True)
  async def process_edit_category_name(message: types.Message, state: FSMContext):
      new_name = message.text.strip()
      
      if not new_name:
          await message.answer("❌ Название категории не может быть пустым. Пожалуйста, попробуйте снова.")
          return
      
      # Get category ID from state
      user_data = await state.get_data()
      category_id = user_data.get("category_id")
      
      if not category_id or category_id not in db.categories:
          await message.answer("❌ Категория не найдена.")
          await state.finish()
          return
      
      # Update category name
      old_name = db.categories[category_id]["name"]
      db.categories[category_id]["name"] = new_name
      
      db.save()
      
      await message.answer(
          f"✅ Название категории изменено с '{old_name}' на '{new_name}'.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  @dp.callback_query_handler(lambda c: c.data.startswith('delete_cat_'), state=AdminStates.edit_category_name)
  async def delete_category(callback_query: types.CallbackQuery, state: FSMContext):
      await bot.answer_callback_query(callback_query.id)
      
      category_id = callback_query.data.replace("delete_cat_", "")
      
      if category_id not in db.categories:
          await bot.send_message(callback_query.from_user.id, "❌ Категория не найдена.")
          await state.finish()
          return
      
      category_name = db.categories[category_id]["name"]
      
      # Get positions in this category
      positions_to_delete = [pos_id for pos_id, pos in db.positions.items() if pos["category_id"] == category_id]
      
      # Get products in these positions
      products_to_delete = [prod_id for prod_id, prod in db.products.items() if prod["position_id"] in positions_to_delete]
      
      # Delete products
      for prod_id in products_to_delete:
          if prod_id in db.products:
              del db.products[prod_id]
      
      # Delete positions
      for pos_id in positions_to_delete:
          if pos_id in db.positions:
              del db.positions[pos_id]
      
      # Delete category
      del db.categories[category_id]
      
      db.save()
      
      await bot.send_message(
          callback_query.from_user.id,
          f"✅ Категория '{category_name}' и все связанные позиции и товары были удалены.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  @dp.callback_query_handler(lambda c: c.data == "cancel_edit_category", state=AdminStates.edit_category_name)
  async def cancel_edit_category(callback_query: types.CallbackQuery, state: FSMContext):
      await bot.answer_callback_query(callback_query.id)
      await bot.send_message(callback_query.from_user.id, "❌ Редактирование категории отменено.", reply_markup=get_product_management_keyboard())
      await state.finish()

  # Create Position handler
  @dp.message_handler(Text(equals="➕ Создать позицию"), is_admin_or_helper=True)
  async def create_position_start(message: types.Message):
      if not db.categories:
          await message.answer("❌ Нет категорий. Пожалуйста, сначала создайте категорию.", reply_markup=get_product_management_keyboard())
          return
      
      await AdminStates.create_position_select_category.set()
      
      markup = InlineKeyboardMarkup()
      for category_id, category in db.categories.items():
          markup.add(InlineKeyboardButton(category["name"], callback_data=f"pos_cat_{category_id}"))
      
      await message.answer(
          safe_html("➕ <b>Создать позицию</b>\n\n"
          "Пожалуйста, выберите категорию для новой позиции:"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.callback_query_handler(lambda c: c.data.startswith('pos_cat_'), state=AdminStates.create_position_select_category)
  async def create_position_name(callback_query: types.CallbackQuery, state: FSMContext):
      await bot.answer_callback_query(callback_query.id)
      
      # Debug the callback data to see its actual format
      callback_data = callback_query.data
      print(f"Debug - Callback data: {callback_data}")
      
      # FIXED: Extract category_id more safely by getting everything after the prefix
      prefix = "pos_cat_"
      if callback_data.startswith(prefix):
          category_id = callback_data[len(prefix):]
          print(f"Debug - Extracted category_id: {category_id}")
      else:
          print(f"Debug - Invalid callback data format: {callback_data}")
          await bot.send_message(callback_query.from_user.id, "❌ Неверный формат данных обратного вызова.")
          await state.finish()
          return
      
      if category_id not in db.categories:
          print(f"Debug - Category not found: {category_id}")
          print(f"Debug - Available categories: {list(db.categories.keys())}")
          await bot.send_message(callback_query.from_user.id, "❌ Категория не найдена.")
          await state.finish()
          return
      
      # Save category ID in state
      await AdminStates.create_position_name.set()
      await state.update_data(category_id=category_id)
      
      await bot.send_message(
          callback_query.from_user.id,
          safe_html(f"➕ <b>Создать позицию</b>\n\n"
          f"Выбранная категория: {db.categories[category_id]['name']}\n\n"
          f"Пожалуйста, введите название для новой позиции:"),
          parse_mode=ParseMode.HTML
      )


  @dp.message_handler(state=AdminStates.create_position_name, is_admin_or_helper=True)
  async def process_position_name(message: types.Message, state: FSMContext):
      position_name = message.text.strip()
      
      if not position_name:
          await message.answer("❌ Название позиции не может быть пустым. Пожалуйста, попробуйте снова.")
          return
      
      # Save position name in state
      await state.update_data(position_name=position_name)
      
      # Move to description state
      await AdminStates.create_position_description.set()
      
      await message.answer(
          "📝 Пожалуйста, введите описание для позиции:"
      )

  @dp.message_handler(state=AdminStates.create_position_description, is_admin_or_helper=True)
  async def process_position_description(message: types.Message, state: FSMContext):
      position_description = message.text.strip()
      
      # Save description in state
      await state.update_data(position_description=position_description)
      
      # Move to price state
      await AdminStates.create_position_price.set()
      
      await message.answer(
          "💰 Пожалуйста, введите цену для позиции (в USD):"
      )

  @dp.message_handler(state=AdminStates.create_position_price, is_admin_or_helper=True)
  async def process_position_price(message: types.Message, state: FSMContext):
      try:
          price = float(message.text.strip())
          
          if price <= 0:
              await message.answer("❌ Цена должна быть больше нуля. Пожалуйста, попробуйте снова.")
              return
          
          # Save price in state
          await state.update_data(position_price=price)
          
          # Move to image state
          await AdminStates.create_position_image.set()
          
          markup = ReplyKeyboardMarkup(resize_keyboard=True)
          markup.add(KeyboardButton("Пропустить изображение"))
          
          await message.answer(
              "🖼️ Пожалуйста, отправьте изображение для позиции или нажмите 'Пропустить изображение':",
              reply_markup=markup
          )
      except ValueError:
          await message.answer("❌ Пожалуйста, введите корректное число.")

  @dp.message_handler(content_types=types.ContentTypes.PHOTO, state=AdminStates.create_position_image, is_admin_or_helper=True)
  async def process_position_image_photo(message: types.Message, state: FSMContext):
      # Get the largest photo (best quality)
      photo = message.photo[-1]
      file_id = photo.file_id
      
      # Save image file_id in state
      await state.update_data(position_image=file_id)
      
      # Create the position
      await create_position_final(message, state, bot)

  @dp.message_handler(lambda message: message.text == "Пропустить изображение", state=AdminStates.create_position_image, is_admin_or_helper=True)
  async def process_position_image_skip(message: types.Message, state: FSMContext):
      # Skip image
      await state.update_data(position_image=None)
      
      # Create the position
      await create_position_final(message, state, bot)

  # Edit Position handler
  @dp.message_handler(Text(equals="✏️ Редактировать позицию"), is_admin_or_helper=True)
  async def edit_position_start(message: types.Message):
      if not db.positions:
          await message.answer("❌ Нет позиций. Пожалуйста, сначала создайте позицию.", reply_markup=get_product_management_keyboard())
          return
      
      await AdminStates.edit_position_select.set()
      
      markup = InlineKeyboardMarkup()
      for position_id, position in db.positions.items():
          category_name = db.categories[position["category_id"]]["name"] if position["category_id"] in db.categories else "Неизвестно"
          markup.add(InlineKeyboardButton(f"{position['name']} ({category_name})", callback_data=f"edit_pos_{position_id}"))
      
      await message.answer(
          safe_html("✏️ <b>Редактировать позицию</b>\n\n"
          "Пожалуйста, выберите позицию для редактирования:"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.callback_query_handler(lambda c: c.data.startswith('edit_pos_'), state=AdminStates.edit_position_select)
  async def edit_position_name_start(callback_query: types.CallbackQuery, state: FSMContext):
      await bot.answer_callback_query(callback_query.id)
      
      position_id = callback_query.data.replace("edit_pos_", "")
      
      if position_id not in db.positions:
          await bot.send_message(callback_query.from_user.id, "❌ Позиция не найдена.")
          await state.finish()
          return
      
      position = db.positions[position_id]
      
      # Save position ID in state
      await AdminStates.edit_position_name.set()
      await state.update_data(position_id=position_id)
      
      markup = InlineKeyboardMarkup()
      markup.add(InlineKeyboardButton("🗑️ Удалить позицию", callback_data=f"delete_pos_{position_id}"))
      markup.add(InlineKeyboardButton("🔙 Отмена", callback_data="cancel_edit_position"))
      
      await bot.send_message(
          callback_query.from_user.id,
          safe_html(f"✏️ <b>Редактировать позицию</b>\n\n"
          f"Текущее название: {position['name']}\n"
          f"Текущее описание: {position['description']}\n"
          f"Текущая цена: {format_currency(position['price'])}\n\n"
          f"Введите новое название для позиции или выберите опцию ниже:"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.message_handler(state=AdminStates.edit_position_name, is_admin_or_helper=True)
  async def process_edit_position_name(message: types.Message, state: FSMContext):
      new_name = message.text.strip()
      
      if not new_name:
          await message.answer("❌ Название позиции не может быть пустым. Пожалуйста, попробуйте снова.")
          return
      
      # Get position ID from state
      user_data = await state.get_data()
      position_id = user_data.get("position_id")
      
      if not position_id or position_id not in db.positions:
          await message.answer("❌ Позиция не найдена.")
          await state.finish()
          return
      
      # Update position name
      old_name = db.positions[position_id]["name"]
      db.positions[position_id]["name"] = new_name
      
      # Move to description state
      await AdminStates.edit_position_description.set()
      
      await message.answer(
          f"✅ Название позиции изменено с '{old_name}' на '{new_name}'.\n\n"
          f"Теперь введите новое описание для позиции:"
      )

  @dp.message_handler(state=AdminStates.edit_position_description, is_admin_or_helper=True)
  async def process_edit_position_description(message: types.Message, state: FSMContext):
      new_description = message.text.strip()
      
      # Get position ID from state
      user_data = await state.get_data()
      position_id = user_data.get("position_id")
      
      if not position_id or position_id not in db.positions:
          await message.answer("❌ Позиция не найдена.")
          await state.finish()
          return
      
      # Update position description
      db.positions[position_id]["description"] = new_description
      
      # Move to price state
      await AdminStates.edit_position_price.set()
      
      await message.answer(
          f"✅ Описание позиции обновлено.\n\n"
          f"Теперь введите новую цену для позиции (в USD):"
      )

  @dp.message_handler(state=AdminStates.edit_position_price, is_admin_or_helper=True)
  async def process_edit_position_price(message: types.Message, state: FSMContext):
      try:
          new_price = float(message.text.strip())
          
          if new_price <= 0:
              await message.answer("❌ Цена должна быть больше нуля. Пожалуйста, попробуйте снова.")
              return
          
          # Get position ID from state
          user_data = await state.get_data()
          position_id = user_data.get("position_id")
          
          if not position_id or position_id not in db.positions:
              await message.answer("❌ Позиция не найдена.")
              await state.finish()
              return
          
          # Update position price
          db.positions[position_id]["price"] = new_price
          
          # Move to image state
          await AdminStates.edit_position_image.set()
          
          markup = ReplyKeyboardMarkup(resize_keyboard=True)
          markup.add(KeyboardButton("Оставить текущее изображение"))
          markup.add(KeyboardButton("Удалить изображение"))
          
          await message.answer(
              f"✅ Цена позиции обновлена до {format_currency(new_price)}.\n\n"
              f"Теперь отправьте новое изображение для позиции или выберите опцию ниже:",
              reply_markup=markup
          )
      except ValueError:
          await message.answer("❌ Пожалуйста, введите корректное число.")

  @dp.message_handler(content_types=types.ContentTypes.PHOTO, state=AdminStates.edit_position_image, is_admin_or_helper=True)
  async def process_edit_position_image_photo(message: types.Message, state: FSMContext):
      # Get the largest photo (best quality)
      photo = message.photo[-1]
      file_id = photo.file_id
      
      # Get position ID from state
      user_data = await state.get_data()
      position_id = user_data.get("position_id")
      
      if not position_id or position_id not in db.positions:
          await message.answer("❌ Позиция не найдена.")
          await state.finish()
          return
      
      # Update position image
      db.positions[position_id]["image_url"] = file_id
      
      # Save changes
      db.save()
      
      await message.answer(
          f"✅ Изображение позиции обновлено.\n\n"
          f"Позиция успешно отредактирована.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  @dp.message_handler(lambda message: message.text == "Оставить текущее изображение", state=AdminStates.edit_position_image, is_admin_or_helper=True)
  async def process_edit_position_image_keep(message: types.Message, state: FSMContext):
      # Get position ID from state
      user_data = await state.get_data()
      position_id = user_data.get("position_id")
      
      if not position_id or position_id not in db.positions:
          await message.answer("❌ Позиция не найдена.")
          await state.finish()
          return
      
      # Save changes
      db.save()
      
      await message.answer(
          f"✅ Изображение позиции оставлено без изменений.\n\n"
          f"Позиция успешно отредактирована.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  @dp.message_handler(lambda message: message.text == "Удалить изображение", state=AdminStates.edit_position_image, is_admin_or_helper=True)
  async def process_edit_position_image_remove(message: types.Message, state: FSMContext):
      # Get position ID from state
      user_data = await state.get_data()
      position_id = user_data.get("position_id")
      
      if not position_id or position_id not in db.positions:
          await message.answer("❌ Позиция не найдена.")
          await state.finish()
          return
      
      # Remove position image
      db.positions[position_id]["image_url"] = None
      
      # Save changes
      db.save()
      
      await message.answer(
          f"✅ Изображение позиции удалено.\n\n"
          f"Позиция успешно отредактирована.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  @dp.callback_query_handler(lambda c: c.data.startswith('delete_pos_'), state=AdminStates.edit_position_name)
  async def delete_position(callback_query: types.CallbackQuery, state: FSMContext):
      await bot.answer_callback_query(callback_query.id)
      
      position_id = callback_query.data.replace("delete_pos_", "")
      
      if position_id not in db.positions:
          await bot.send_message(callback_query.from_user.id, "❌ Позиция не найдена.")
          await state.finish()
          return
      
      position = db.positions[position_id]
      position_name = position["name"]
      category_id = position["category_id"]
      
      # Get products in this position
      products_to_delete = [prod_id for prod_id, prod in db.products.items() if prod["position_id"] == position_id]
      
      # Delete products
      for prod_id in products_to_delete:
          if prod_id in db.products:
              del db.products[prod_id]
      
      # Remove position from category
      if category_id in db.categories and "positions" in db.categories[category_id]:
          if position_id in db.categories[category_id]["positions"]:
              db.categories[category_id]["positions"].remove(position_id)
      
      # Delete position
      del db.positions[position_id]
      
      db.save()
      
      await bot.send_message(
          callback_query.from_user.id,
          f"✅ Позиция '{position_name}' и все связанные товары были удалены.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  @dp.callback_query_handler(lambda c: c.data == "cancel_edit_position", state=AdminStates.edit_position_name)
  async def cancel_edit_position(callback_query: types.CallbackQuery, state: FSMContext):
      await bot.answer_callback_query(callback_query.id)
      await bot.send_message(callback_query.from_user.id, "❌ Редактирование позиции отменено.", reply_markup=get_product_management_keyboard())
      await state.finish()

  # Delete All Positions handler
  @dp.message_handler(Text(equals="🗑️ Удалить все позиции"), is_admin_or_helper=True)
  async def delete_all_positions(message: types.Message):
      markup = InlineKeyboardMarkup()
      markup.add(InlineKeyboardButton("✅ Да, удалить все", callback_data="confirm_delete_all_positions"))
      markup.add(InlineKeyboardButton("❌ Нет, отменить", callback_data="cancel_delete_all_positions"))
      
      await message.answer(
          safe_html("🗑️ <b>Удалить все позиции</b>\n\n"
          "⚠️ ВНИМАНИЕ: Это удалит ВСЕ позиции и товары. Это действие нельзя отменить.\n\n"
          "Вы уверены, что хотите продолжить?"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.callback_query_handler(lambda c: c.data == "confirm_delete_all_positions", is_admin_callback=True)
  async def confirm_delete_all_positions(callback_query: types.CallbackQuery):
      await bot.answer_callback_query(callback_query.id)
      
      # Clear all positions and products
      db.positions = {}
      db.products = {}
      
      # Clear positions from categories
      for category_id in db.categories:
          if "positions" in db.categories[category_id]:
              db.categories[category_id]["positions"] = []
      
      db.save()
      
      await bot.send_message(
          callback_query.from_user.id,
          "✅ Все позиции и товары были удалены.",
          reply_markup=get_product_management_keyboard()
      )

  @dp.callback_query_handler(lambda c: c.data == "cancel_delete_all_positions", is_admin_callback=True)
  async def cancel_delete_all_positions(callback_query: types.CallbackQuery):
      await bot.answer_callback_query(callback_query.id)
      await bot.send_message(callback_query.from_user.id, "❌ Операция отменена.", reply_markup=get_product_management_keyboard())

  # Add Products handler
  @dp.message_handler(Text(equals="➕ Добавить товары"), is_admin_or_helper=True)
  async def add_products_start(message: types.Message):
      if not db.positions:
          await message.answer("❌ Нет позиций. Пожалуйста, сначала создайте позицию.", reply_markup=get_product_management_keyboard())
          return
      
      await AdminStates.add_product_select_position.set()
      
      markup = InlineKeyboardMarkup()
      for position_id, position in db.positions.items():
          category_name = db.categories[position["category_id"]]["name"] if position["category_id"] in db.categories else "Неизвестно"
          markup.add(InlineKeyboardButton(f"{position['name']} ({category_name})", callback_data=f"add_prod_{position_id}"))
      
      await message.answer(
          safe_html("➕ <b>Добавить товары</b>\n\n"
          "Пожалуйста, выберите позицию, к которой нужно добавить товары:"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.callback_query_handler(lambda c: c.data.startswith('add_prod_'), state=AdminStates.add_product_select_position)
  async def add_product_start(callback_query: types.CallbackQuery, state: FSMContext):
      await bot.answer_callback_query(callback_query.id)
      
      # Fix: Use replace instead of split to get the position ID
      position_id = callback_query.data.replace("add_prod_", "")
      
      # Add logging to debug
      import logging
      logging.info(f"Adding product to position: {position_id}")
      logging.info(f"Available positions: {list(db.positions.keys())}")
      
      if position_id not in db.positions:
          await bot.send_message(callback_query.from_user.id, "❌ Позиция не найдена.")
          await state.finish()
          return
      
      position = db.positions[position_id]
      
      # Save position ID in state
      await AdminStates.add_product_content.set()
      await state.update_data(position_id=position_id)
      
      await bot.send_message(
          callback_query.from_user.id,
          safe_html(f"➕ <b>Добавить товары</b>\n\n"
          f"Выбранная позиция: {position['name']}\n\n"
          f"Пожалуйста, введите содержимое товара. Каждая строка будет считаться отдельным товаром:"),
          parse_mode=ParseMode.HTML
      )

  @dp.message_handler(state=AdminStates.add_product_content, is_admin_or_helper=True)
  async def process_product_content(message: types.Message, state: FSMContext):
      content_lines = message.text.strip().split('\n')
      
      if not content_lines or not content_lines[0]:
          await message.answer("❌ Содержимое товара не может быть пустым. Пожалуйста, попробуйте снова.")
          return
      
      user_data = await state.get_data()
      position_id = user_data.get("position_id")
      
      # Add each line as a separate product
      added_count = 0
      for line in content_lines:
          if line.strip():
              # Generate a unique product ID
              product_id = f"prod_{len(db.products) + 1 + added_count}"
              
              # Add the product
              db.products[product_id] = {
                  "id": product_id,
                  "content": line.strip(),
                  "position_id": position_id
              }
              
              added_count += 1
      
      db.save()
      
      await message.answer(
          f"✅ Добавлено {added_count} товаров к позиции '{db.positions[position_id]['name']}'.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  # Delete Product handler
  @dp.message_handler(Text(equals="🗑️ Удалить товар"), is_admin_or_helper=True)
  async def delete_product_start(message: types.Message):
      if not db.products:
          await message.answer("❌ Нет товаров.", reply_markup=get_product_management_keyboard())
          return
      
      await AdminStates.delete_product_id.set()
      
      await message.answer(
          safe_html("🗑️ <b>Удалить товар</b>\n\n"
          "Пожалуйста, введите ID товара для удаления:"),
          parse_mode=ParseMode.HTML
      )

  @dp.message_handler(state=AdminStates.delete_product_id, is_admin_or_helper=True)
  async def process_delete_product(message: types.Message, state: FSMContext):
      product_id = message.text.strip()
      
      if product_id not in db.products:
          await message.answer("❌ Товар не найден. Пожалуйста, попробуйте снова или вернитесь в меню управления товарами.", reply_markup=get_product_management_keyboard())
          await state.finish()
          return
      
      # Delete the product
      position_id = db.products[product_id]["position_id"]
      position_name = db.positions[position_id]["name"] if position_id in db.positions else "Неизвестно"
      
      del db.products[product_id]
      db.save()
      
      await message.answer(
          f"✅ Товар (ID: {product_id}) из позиции '{position_name}' был удален.",
          reply_markup=get_product_management_keyboard()
      )
      
      await state.finish()

  # Delete All Products handler
  @dp.message_handler(Text(equals="🗑️ Удалить товары"), is_admin_or_helper=True)
  async def delete_all_products(message: types.Message):
      markup = InlineKeyboardMarkup()
      markup.add(InlineKeyboardButton("✅ Да, удалить все", callback_data="confirm_delete_all_products"))
      markup.add(InlineKeyboardButton("❌ Нет, отменить", callback_data="cancel_delete_all_products"))
      
      await message.answer(
          safe_html("🗑️ <b>Удалить товары</b>\n\n"
          "⚠️ ВНИМАНИЕ: Это удалит ВСЕ товары. Это действие нельзя отменить.\n\n"
          "Вы уверены, что хотите продолжить?"),
          reply_markup=markup,
          parse_mode=ParseMode.HTML
      )

  @dp.callback_query_handler(lambda c: c.data == "confirm_delete_all_products", is_admin_callback=True)
  async def confirm_delete_all_products(callback_query: types.CallbackQuery):
      await bot.answer_callback_query(callback_query.id)
      
      # Clear all products
      db.products = {}
      db.save()
      
      await bot.send_message(
          callback_query.from_user.id,
          "✅ Все товары были удалены.",
          reply_markup=get_product_management_keyboard()
      )

  @dp.callback_query_handler(lambda c: c.data == "cancel_delete_all_products", is_admin_callback=True)
  async def cancel_delete_all_products(callback_query: types.CallbackQuery):
      await bot.answer_callback_query(callback_query.id)
      await bot.send_message(callback_query.from_user.id, "❌ Операция отменена.", reply_markup=get_product_management_keyboard())

# Helper functions
async def create_position_final(message, state, bot):
  # Get all position data from state
  user_data = await state.get_data()
  category_id = user_data.get("category_id")
  position_name = user_data.get("position_name")
  position_description = user_data.get("position_description")
  position_price = user_data.get("position_price")
  position_image = user_data.get("position_image")
  
  # Generate a unique position ID
  position_id = f"pos_{len(db.positions) + 1}"
  
  # Create the position
  db.positions[position_id] = {
      "id": position_id,
      "name": position_name,
      "description": position_description,
      "price": position_price,
      "image_url": position_image,
      "category_id": category_id
  }
  
  # Add position to category
  if "positions" not in db.categories[category_id]:
      db.categories[category_id]["positions"] = []
  
  db.categories[category_id]["positions"].append(position_id)
  
  db.save()
  
  await message.answer(
      f"✅ Позиция '{position_name}' успешно создана.",
      reply_markup=get_product_management_keyboard()
  )
  
  await state.finish()


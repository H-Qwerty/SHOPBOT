from aiogram import types
from aiogram.dispatcher.filters import BoundFilter
from config import ADMIN_IDS, HELPER_IDS


class IsAdmin(BoundFilter):
    """
    Filter that checks if user is an admin
    """
    key = 'is_admin'
    
    def __init__(self, is_admin=True):
        self.is_admin = is_admin
    
    async def check(self, message: types.Message):
        return (message.from_user.id in ADMIN_IDS) == self.is_admin


class IsHelper(BoundFilter):
    """
    Filter that checks if user is a helper
    """
    key = 'is_helper'
    
    def __init__(self, is_helper=True):
        self.is_helper = is_helper
    
    async def check(self, message: types.Message):
        return (message.from_user.id in HELPER_IDS) == self.is_helper


class IsAdminOrHelper(BoundFilter):
    """
    Filter that checks if user is an admin or helper
    """
    key = 'is_admin_or_helper'
    
    def __init__(self, is_admin_or_helper=True):
        self.is_admin_or_helper = is_admin_or_helper
    
    async def check(self, message: types.Message):
        is_user_admin_or_helper = message.from_user.id in ADMIN_IDS or message.from_user.id in HELPER_IDS
        return is_user_admin_or_helper == self.is_admin_or_helper


class IsAdminCallback(BoundFilter):
    """
    Filter that checks if callback query is from an admin
    """
    key = 'is_admin_callback'
    
    def __init__(self, is_admin_callback=True):
        self.is_admin_callback = is_admin_callback
    
    async def check(self, callback_query: types.CallbackQuery):
        return (callback_query.from_user.id in ADMIN_IDS) == self.is_admin_callback


class IsHelperCallback(BoundFilter):
    """
    Filter that checks if callback query is from a helper
    """
    key = 'is_helper_callback'
    
    def __init__(self, is_helper_callback=True):
        self.is_helper_callback = is_helper_callback
    
    async def check(self, callback_query: types.CallbackQuery):
        return (callback_query.from_user.id in HELPER_IDS) == self.is_helper_callback


class IsAdminOrHelperCallback(BoundFilter):
    """
    Filter that checks if callback query is from an admin or helper
    """
    key = 'is_admin_or_helper_callback'
    
    def __init__(self, is_admin_or_helper_callback=True):
        self.is_admin_or_helper_callback = is_admin_or_helper_callback
    
    async def check(self, callback_query: types.CallbackQuery):
        is_user_admin_or_helper = callback_query.from_user.id in ADMIN_IDS or callback_query.from_user.id in HELPER_IDS
        return is_user_admin_or_helper == self.is_admin_or_helper_callback


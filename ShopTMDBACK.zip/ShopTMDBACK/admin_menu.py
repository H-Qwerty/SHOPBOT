
import asyncio
import logging
from datetime import datetime

from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ParseMode, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

from database import db, format_currency
from keyboards import (
    get_main_keyboard, get_admin_keyboard, get_settings_keyboard, 
    get_product_management_keyboard, get_user_management_keyboard,
    get_receipt_management_keyboard, get_categories_inline_keyboard,
    get_helper_keyboard
)
from states import AdminStates
from utils import safe_html, format_html_message
from config import ADMIN_IDS, HELPER_IDS



def register_admin_handlers(dp, bot):
    # Admin panel entry point
    @dp.message_handler(Text(equals="⚙️ Админ панель"), is_admin=True)
    async def admin_panel(message: types.Message):
        await message.answer(
            safe_html("⚙️ <b>Admin Panel</b>\n\n"
            "Welcome to the admin panel. Please select an option:"),
            reply_markup=get_admin_keyboard(),
            parse_mode=ParseMode.HTML
        )


    # Back to main menu handler
    @dp.message_handler(Text(equals="🔙 Назад в меню"), is_admin=True)
    async def back_to_main_menu(message: types.Message):
        await message.answer(
            "🔙 Returned to main menu.",
            reply_markup=get_main_keyboard(message.from_user.id)
        )

    
    @dp.message_handler(Text(equals="📦 Товар"), is_admin=True)
    async def product_management(message: types.Message):
        await message.answer(
            safe_html("📦 <b>Управление товарами</b>\n\n"
            "Выберите действие из меню ниже:"),
            reply_markup=get_product_management_keyboard(),
            parse_mode=ParseMode.HTML
        )

    # Back to admin panel handler
    @dp.message_handler(Text(equals="🔙 Назад в Админ меню"), is_admin=True)
    async def back_to_admin_panel(message: types.Message):
        await message.answer(
            "🔙 Returned to admin panel.",
            reply_markup=get_admin_keyboard()
        )

    # Settings handler
    @dp.message_handler(Text(equals="⚙️ Настройки"), is_admin=True)
    async def settings_menu(message: types.Message):
        await message.answer(
            safe_html("⚙️ <b>Настройки</b>\n\n"
            "Current status:\n"
            f"🛠️ Тех.Работы: {'✅ Вкл' if db.settings['maintenance_mode'] else '❌ Выкл'}\n"
            f"🛒 Покупки: {'✅ Вкл' if db.settings['purchases_enabled'] else '❌ Выкл'}\n"
            f"💰 Пополнения баланса: {'✅ Вкл' if db.settings['topup_enabled'] else '❌ Выкл'}\n"
            f"🔑 Crypto Bot токен: {'✅ Установлен' if db.settings['crypto_bot_token'] else '❌ Не установлен'}\n\n"
            "Выберите вариант изменения настроек:"),
            reply_markup=get_settings_keyboard(),
            parse_mode=ParseMode.HTML
        )

    # Change FAQ handler
    @dp.message_handler(Text(equals="📝 Изменить FAQ"), is_admin=True)
    async def change_faq_start(message: types.Message):
        await AdminStates.change_faq.set()
        
        await message.answer(
            safe_html("📝 <b>Изменить FAQ</b>\n\n"
            "Пожалуйста, введите новый текст FAQ. Вы можете использовать форматирование HTML и следующие заполнители.:\n"
            "{id} - User ID\n"
            "{name} - User's имя\n"
            "{username} - User's username\n\n"
            "Текущий FAQ:\n\n" + db.settings["faq"]),
            parse_mode=ParseMode.HTML
        )

    # Process FAQ change
    @dp.message_handler(state=AdminStates.change_faq, is_admin=True)
    async def process_faq_change(message: types.Message, state: FSMContext):
        new_faq = safe_html(message.text)
        
        # Save new FAQ
        db.settings["faq"] = new_faq
        db.save()
        
        await state.finish()
        await message.answer("✅ FAQ был успешно изменен.", reply_markup=get_settings_keyboard())

    # Change Support handler
    @dp.message_handler(Text(equals="👨‍💻 Изменить Поддержку"), is_admin=True)
    async def change_support_start(message: types.Message):
        await AdminStates.change_support.set()
        
        current_support = f"<code>{db.settings['support_id']}</code>" if db.settings['support_id'] else "Not set"
        
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add(KeyboardButton("👨‍💻 Сделать моим ID"))
        markup.add(KeyboardButton("❌ Удалить Поддержку"))
        markup.add(KeyboardButton("🔙 Назад"))
        
        await message.answer(
            safe_html("👨‍💻 <b>Изменить поддержку</b>\n\n"
            f"Текущая Поддержка ID: {current_support}\n\n"
            "Введите новый идентификатор пользователя службы поддержки или выберите вариант ниже:"),
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )

    @dp.message_handler(Text(equals="📦 Управление товарми"), is_admin=True)
    async def product_management(message: types.Message):
        await message.answer(
            safe_html("📦 <b>Управление товарами</b>\n\n"
            "Выберите действие из меню ниже:"),
            reply_markup=get_product_management_keyboard(),
            parse_mode=ParseMode.HTML
        )

    # Process Support change
    @dp.message_handler(state=AdminStates.change_support, is_admin=True)
    async def process_support_change(message: types.Message, state: FSMContext):
        text = message.text
        
        if text == "👨‍💻 Сделать моим ID":
            db.settings["support_id"] = message.from_user.id
            db.save()
            await state.finish()
            await message.answer("✅ Поддержка ID установлен на ваш идентификатор.", reply_markup=get_settings_keyboard())
        elif text == "❌ Удалить Поддержку":
            db.settings["support_id"] = None
            db.save()
            await state.finish()
            await message.answer("✅ Поддержка ID была удалена.", reply_markup=get_settings_keyboard())
        elif text == "🔙 Назад":
            await state.finish()
            await message.answer("❌ Операция отклонена.", reply_markup=get_settings_keyboard())
        else:
            try:
                support_id = int(text.strip())
                db.settings["support_id"] = support_id
                db.save()
                await state.finish()
                await message.answer("✅ Поддержка ID была успешно обновлена.", reply_markup=get_settings_keyboard())
            except ValueError:
                await message.answer("❌ Пожалуйста, введите корректный user ID (только цифры).")

    # Toggle Maintenance handler
    @dp.message_handler(Text(equals="🔌 Тех.Работы"), is_admin_or_helper=True)
    async def toggle_maintenance(message: types.Message):
        db.settings["maintenance_mode"] = not db.settings["maintenance_mode"]
        db.save()
        
        status = "включен" if db.settings["maintenance_mode"] else "выключен"
        
        # Determine which keyboard to return based on user role
        keyboard = get_admin_keyboard() if message.from_user.id in ADMIN_IDS else get_helper_keyboard()
        
        await message.answer(
            safe_html(f"✅ Режим тех.работ {status}."),
            reply_markup=keyboard
        )

    # Toggle Purchases handler
    @dp.message_handler(Text(equals="🛒 Покупки"), is_admin=True)
    async def toggle_purchases(message: types.Message):
        db.settings["purchases_enabled"] = not db.settings["purchases_enabled"]
        db.save()
        
        status = "enabled" if db.settings["purchases_enabled"] else "disabled"
        await message.answer(
            safe_html(f"✅ Покупки были {status}."),
            reply_markup=get_settings_keyboard()
        )

    # Toggle Top-ups handler
    @dp.message_handler(Text(equals="💰 Пополнения баланса"), is_admin=True)
    async def toggle_topups(message: types.Message):
        db.settings["topup_enabled"] = not db.settings["topup_enabled"]
        db.save()
        
        status = "enabled" if db.settings["topup_enabled"] else "disabled"
        await message.answer(
            safe_html(f"✅ Пополнения баланса были {status}."),
            reply_markup=get_settings_keyboard()
        )

    # Crypto Bot Token handler
    @dp.message_handler(Text(equals="🔑 Crypto Bot токен"), is_admin=True)
    async def change_crypto_token_start(message: types.Message):
        await AdminStates.change_crypto_token.set()
        
        current_token = "Токен установлен" if db.settings.get("crypto_bot_token") else "Токен не установлен"
        
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add(KeyboardButton("❌ Удалить токен"))
        markup.add(KeyboardButton("🔙 Назад"))
        
        await message.answer(
            safe_html("🔑 <b>Crypto Bot токен</b>\n\n"
            f"Current status: {current_token}\n\n"
            "Введите новый токен API Crypto Bot или выберите вариант ниже:"),
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )

    # Process Crypto Bot token change
    @dp.message_handler(state=AdminStates.change_crypto_token, is_admin=True)
    async def process_crypto_token_change(message: types.Message, state: FSMContext):
        text = message.text
        
        if text == "❌ Удалить токен":
            db.settings["crypto_bot_token"] = None
            db.save()
            await state.finish()
            await message.answer("✅ Crypto Bot был успешно удален.", reply_markup=get_settings_keyboard())
        elif text == "🔙 Назад":
            await state.finish()
            await message.answer("❌ Операция отклонена.", reply_markup=get_settings_keyboard())
        else:
            # Save new token
            db.settings["crypto_bot_token"] = text.strip()
            
            # No need to update the global variable in config anymore
            # The database.py file will now use the token from settings
            
            db.save()
            await state.finish()
            await message.answer("✅ Crypto Bot был успешно обновлен.", reply_markup=get_settings_keyboard())

    # User Management handler
    @dp.message_handler(Text(equals="👥 Управление пользователями"), is_admin=True)
    async def user_management(message: types.Message):
        await message.answer(
            safe_html("👥 <b>Управление пользователями</b>\n\n"
            "Total users: " + str(db.stats["total_users"])),
            reply_markup=get_user_management_keyboard(),
            parse_mode=ParseMode.HTML
        )

    # Search Profile handler
    @dp.message_handler(Text(equals="🔍 Искать профиль"), is_admin=True)
    async def search_profile_start(message: types.Message):
        await AdminStates.search_profile.set()
        
        await message.answer(
            safe_html("🔍 <b>Искать профиль</b>\n\n"
            "Пожалуйста, введите ID или имя пользователя для поиска:"),
            parse_mode=ParseMode.HTML
        )

    # Process Profile Search
    @dp.message_handler(state=AdminStates.search_profile, is_admin=True)
    async def process_profile_search(message: types.Message, state: FSMContext):
        search_term = message.text.strip()
        
        # Try to find user by ID or username
        user_id = None
        
        # Check if search term is a user ID
        if search_term.isdigit():
            if search_term in db.users:
                user_id = search_term
        
        # If not found by ID, try to find by username
        if not user_id and search_term.startswith('@'):
            search_term = search_term[1:]  # Remove @ symbol
        
        if not user_id:
            # Search by username
            for uid, user in db.users.items():
                if user.get('username') and user['username'].lower() == search_term.lower():
                    user_id = uid
                    break
        
        if not user_id:
            await message.answer("❌ Пользователь не найден. Пожалуйста, повторите попытку или вернитесь в меню управления пользователями.", reply_markup=get_user_management_keyboard())
            await state.finish()
            return
        
        # Found user, display profile
        user = db.users[user_id]
        
        profile_text = (
            f"👤 <b>Профиль пользователя</b>\n\n"
            f"🆔 ID: <code>{user['id']}</code>\n"
        )
        
        if user.get('username'):
            profile_text += f"🔤 Username: @{user['username']}\n"
        
        profile_text += (
            f"👤 Имя: {user.get('first_name', 'Unknown')}\n"
            f"💰 Баланс: {format_currency(user['balance'])}\n"
            f"🛒 Покупки: {len(user['purchases'])}\n"
            f"📅 Присоеденился: {user['join_date']}\n"
            f"🕒 Последняя активность: {user['last_activity']}"
        )
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("💰 Изменить баланс", callback_data=f"change_balance_{user_id}"))
        markup.add(InlineKeyboardButton("✉️ Отправить сообщение", callback_data=f"send_message_{user_id}"))
        markup.add(InlineKeyboardButton("🧾 Посмотреть покупки", callback_data=f"view_purchases_{user_id}"))
        
        await message.answer(
            safe_html(profile_text),
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )
        
        await state.finish()

    # Change Balance handler
    @dp.callback_query_handler(lambda c: c.data.startswith('change_balance_'), is_admin_callback=True)
    async def change_balance_start(callback_query: types.CallbackQuery, state: FSMContext):
        await bot.answer_callback_query(callback_query.id)
        
        user_id = callback_query.data.split('_')[2]
        
        if user_id not in db.users:
            await bot.send_message(callback_query.from_user.id, "❌ Пользователь не найден.")
            return
        
        # Save user ID in state
        await AdminStates.change_balance.set()
        await state.update_data(user_id=user_id)
        
        user = db.users[user_id]
        
        await bot.send_message(
            callback_query.from_user.id,
            safe_html(f"💰 <b>Изменить баланс</b>\n\n"
            f"Пользователь: {user.get('first_name', 'Unknown')} (ID: <code>{user_id}</code>)\n"
            f"Текущий баланс: {format_currency(user['balance'])}\n\n"
            f"Пожалуйста, введите новый баланс:"),
            parse_mode=ParseMode.HTML
        )

    # Process Balance Change
    @dp.message_handler(state=AdminStates.change_balance, is_admin=True)
    async def process_balance_change(message: types.Message, state: FSMContext):
        try:
            new_balance = float(message.text.strip())
            
            if new_balance < 0:
                await message.answer("❌ Баланс не может быть отрицательным. Пожалуйста, попробуйте еще раз.")
                return
            
            # Get user ID from state
            user_data = await state.get_data()
            user_id = user_data.get("user_id")
            
            if not user_id or user_id not in db.users:
                await message.answer("❌ Пользователь не найден.")
                await state.finish()
                return
            
            # Update user balance
            old_balance = db.users[user_id]["balance"]
            db.users[user_id]["balance"] = new_balance
            
            # Update total user balance in stats
            db.stats["total_user_balance"] += (new_balance - old_balance)
            
            db.save()
            
            await message.answer(
                safe_html(f"✅ Баланс для пользователя {db.users[user_id].get('first_name', 'Unknown')} (ID: <code>{user_id}</code>) был успешно обновлен на {format_currency(new_balance)}."),
                reply_markup=get_user_management_keyboard(),
                parse_mode=ParseMode.HTML
            )
            
            # Notify user about balance change
            try:
                await bot.send_message(
                    int(user_id),
                    safe_html(f"💰 <b>Баланс изменен</b>\n\n"
                    f"Ваш баланс обновлен Администратором.\n"
                    f"Новый баланс: {format_currency(new_balance)}"),
                    parse_mode=ParseMode.HTML
                )
            except Exception as e:
                logging.error(f"Не удалось уведомить пользователя {user_id} об изменение его баланса: {e}")
            
            await state.finish()
            
        except ValueError:
            await message.answer("❌ Введите корректный номер.")

    # Send Message handler
    @dp.callback_query_handler(lambda c: c.data.startswith('send_message_'), is_admin_callback=True)
    async def send_message_start(callback_query: types.CallbackQuery, state: FSMContext):
        await bot.answer_callback_query(callback_query.id)
        
        user_id = callback_query.data.split('_')[2]
        
        if user_id not in db.users:
            await bot.send_message(callback_query.from_user.id, "❌ Пользователь не найден.")
            return
        
        # Save user ID in state
        await AdminStates.send_message.set()
        await state.update_data(user_id=user_id)
        
        user = db.users[user_id]
        
        await bot.send_message(
            callback_query.from_user.id,
            safe_html(f"✉️ <b>Отправить сообщение</b>\n\n"
            f"Пользователь: {user.get('first_name', 'Unknown')} (ID: <code>{user_id}</code>)\n\n"
            f"Введите сообщение, которое вы хотите отправить этому пользователю. Вы можете использовать форматирование HTML:"),
            parse_mode=ParseMode.HTML
        )

    # Process Send Message
    @dp.message_handler(state=AdminStates.send_message, is_admin=True)
    async def process_send_message(message: types.Message, state: FSMContext):
        message_text = safe_html(message.text)
        
        # Get user ID from state
        user_data = await state.get_data()
        user_id = user_data.get("user_id")
        
        if not user_id or user_id not in db.users:
            await message.answer("❌ Пользователь не найден.")
            await state.finish()
            return
        
        # Send message to user
        try:
            await bot.send_message(
                int(user_id),
                safe_html(f"📨 <b>Сообщение от Администратор</b>\n\n{message_text}"),
                parse_mode=ParseMode.HTML
            )
            
            await message.answer(
                safe_html(f"✅ Сообщение отправлено пользователю {db.users[user_id].get('first_name', 'Unknown')} (ID: <code>{user_id}</code>)."),
                reply_markup=get_user_management_keyboard(),
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logging.error(f"Не удалось отправить сообщение пользователю {user_id}: {e}")
            await message.answer(f"❌ Не удалось отправить сообщение: {e}", reply_markup=get_user_management_keyboard())
        
        await state.finish()

    # View Purchases handler
    @dp.callback_query_handler(lambda c: c.data.startswith('view_purchases_'), is_admin_callback=True)
    async def view_purchases(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        user_id = callback_query.data.split('_')[2]
        
        if user_id not in db.users:
            await bot.send_message(callback_query.from_user.id, "❌ Пользователь не найден.")
            return
        
        user = db.users[user_id]
        
        if not user["purchases"]:
            await bot.send_message(
                callback_query.from_user.id,
                safe_html(f"😢 Пользователь {user.get('first_name', 'Unknown')} (ID: <code>{user_id}</code>) еще не сделал ни одной покупки."),
                parse_mode=ParseMode.HTML
            )
            return
        
        purchases_text = safe_html(f"🛒 <b>Покупки для {user.get('first_name', 'Unknown')}</b> (ID: <code>{user_id}</code>)\n\n")
        
        for receipt_id in user["purchases"]:
            if receipt_id in db.receipts:
                receipt = db.receipts[receipt_id]
                purchases_text += safe_html(
                    f"🧾 Чек: <code>{receipt_id}</code>\n"
                    f"📦 Товар: {receipt.get('product_name', 'Unknown')}\n"
                    f"💰 Цена: {format_currency(receipt.get('amount', 0))}\n"
                    f"📅 Дата: {receipt.get('date', 'Unknown')}\n\n"
                )
        
        await bot.send_message(
            callback_query.from_user.id,
            purchases_text,
            parse_mode=ParseMode.HTML
        )

    # Receipt Management handler
    @dp.message_handler(Text(equals="🧾 Управление чеками"), is_admin=True)
    async def receipt_management(message: types.Message):
        await message.answer(
            safe_html("🧾 <b>Управление чеками</b>\n\n"
            "Total receipts: " + str(len(db.receipts))),
            reply_markup=get_receipt_management_keyboard(),
            parse_mode=ParseMode.HTML
        )

    # Search Receipt handler
    @dp.message_handler(Text(equals="🔍 Искать чек"), is_admin=True)
    async def search_receipt_start(message: types.Message):
        await AdminStates.search_receipt.set()
        
        await message.answer(
            safe_html("🔍 <b>Искать чек</b>\n\n"
            "Пожалуйста, введите ID чека для поиска:"),
            parse_mode=ParseMode.HTML
        )

    # Process Receipt Search
    @dp.message_handler(state=AdminStates.search_receipt, is_admin=True)
    async def process_receipt_search(message: types.Message, state: FSMContext):
        receipt_id = message.text.strip()
        
        if receipt_id not in db.receipts:
            await message.answer("❌ Чек не найдена. Пожалуйста, повторите попытку или вернитесь в меню управления квитанциями.", reply_markup=get_receipt_management_keyboard())
            await state.finish()
            return
        
        # Found receipt, display details
        receipt = db.receipts[receipt_id]
        user_id = str(receipt["user_id"])
        
        receipt_text = (
            f"🧾 <b>Детали чека</b>\n\n"
            f"🆔 ID: <code>{receipt_id}</code>\n"
            f"👤 Пользователь: "
        )
        
        if user_id in db.users:
            user = db.users[user_id]
            receipt_text += f"{user.get('first_name', 'Unknown')} (ID: <code>{user_id}</code>)"
            if user.get('username'):
                receipt_text += f", @{user['username']}"
        else:
            receipt_text += f"Unknown (ID: <code>{user_id}</code>)"
        
        receipt_text += (
            f"\n📅 Дата: {receipt.get('date', 'Unknown')}\n"
            f"💰 Цена: {format_currency(receipt.get('amount', 0))}\n"
            f"🏷️ Тип: {receipt.get('type', 'Unknown')}\n"
        )
        
        if receipt.get('type') == 'purchase':
            receipt_text += (
                f"📦 Товар: {receipt.get('product_name', 'Unknown')}\n"
                f"📂 Категория: {receipt.get('category_name', 'Unknown')}\n"
            )
        elif receipt.get('type') == 'topup':
            receipt_text += (
                f"💳 Способ оплаты: {receipt.get('payment_method', 'Unknown')}\n"
            )
        
        receipt_text += f"✅ Статус оплаты: {receipt.get('status', 'Unknown')}"
        
        await message.answer(
            safe_html(receipt_text),
            reply_markup=get_receipt_management_keyboard(),
            parse_mode=ParseMode.HTML
        )
        
        await state.finish()

    # Broadcast handler
    @dp.message_handler(Text(equals="📨 Рассылка"), is_admin_or_helper=True)
    async def broadcast_start(message: types.Message):
        await AdminStates.broadcast_message.set()
        
        await message.answer(
            safe_html("📨 <b>Рассылка</b>\n\n"
            "Введите сообщение, которое вы хотите отправить всем пользователям. Вы можете использовать форматирование HTML."),
            parse_mode=ParseMode.HTML
        )

    # Process broadcast
    @dp.message_handler(state=AdminStates.broadcast_message, is_admin_or_helper=True)
    async def process_broadcast(message: types.Message, state: FSMContext):
        broadcast_text = safe_html(message.text)
        
        await message.answer("📨 Рассылка сообщения всем пользователям. Это может занять некоторое время...")
        
        # Counter for successful and failed deliveries
        success_count = 0
        blocked_count = 0
        
        # Send message to all users
        for user_id in db.users:
            try:
                await bot.send_message(
                    chat_id=int(user_id),
                    text=safe_html(f"📢 <b>Объявление</b>\n\n{broadcast_text}"),
                    parse_mode=ParseMode.HTML
                )
                success_count += 1
                # Add a small delay to avoid hitting rate limits
                await asyncio.sleep(0.1)
            except Exception as e:
                blocked_count += 1
                logging.error(f"Не удалось отправить объявление пользователю {user_id}: {e}")
        
        # Determine which keyboard to return based on user role
        keyboard = get_admin_keyboard() if message.from_user.id in ADMIN_IDS else get_helper_keyboard()
        
        await message.answer(
            safe_html(f"📨 <b>Рассылка завершена</b>\n\n"
            f"✅ Успешно отправлено: {success_count}\n"
            f"❌ Не отправлено/Заблокировано: {blocked_count}"),
            reply_markup=keyboard,
            parse_mode=ParseMode.HTML
        )
        
        await state.finish()

    # Statistics handler
    @dp.message_handler(Text(equals="📊 Статистика"), is_admin_or_helper=True)
    async def show_statistics(message: types.Message):
        stats_text = (
            f"📊 <b>Статистика</b>\n\n"
            f"👥 Всего пользователей: {db.stats['total_users']}\n"
            f"🛒 Всего покупол: {db.stats['total_purchases']}\n"
            f"💰 Всего пополнили баланс на: {db.stats['total_topups']}\n"
            f"📦 Товаров продано: {db.stats['total_products_sold']}\n"
            f"💵 Всего больших балансов: {format_currency(db.stats['total_revenue'])}\n"
            f"💰 Всего потратили: {format_currency(db.stats['total_user_balance'])}\n\n"
            f"📦 Актуальных товаров: {len(db.products)}\n"
            f"📂 Категорий: {len(db.categories)}\n"
            f"🏷️ Позиций: {len(db.positions)}"
        )
        
        # Determine which keyboard to return based on user role
        keyboard = get_admin_keyboard() if message.from_user.id in ADMIN_IDS else get_helper_keyboard()
        
        await message.answer(
            safe_html(stats_text),
            reply_markup=keyboard,
            parse_mode=ParseMode.HTML
        )

    # Payment Methods handler
    @dp.message_handler(Text(equals="💰 Способы оплаты"), is_admin=True)
    async def payment_methods(message: types.Message):
        methods = db.settings["payment_methods"]
        
        methods_text = "💰 <b>Способы оплаты</b>\n\n"
        
        if "crypto" in methods:
            crypto_status = "✅ Включено" if db.settings.get("crypto_bot_token") else "❌ Выключено"
            methods_text += f"🔹 Crypto: {crypto_status}\n"
        
        markup = InlineKeyboardMarkup()
        
        # Toggle buttons for each method
        markup.add(InlineKeyboardButton(
            "🔄 Изменить Crypto", callback_data="toggle_method_crypto"
        ))
        
        await message.answer(
            safe_html(methods_text),
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )

    # Toggle Payment Method handler
    @dp.callback_query_handler(lambda c: c.data.startswith('toggle_method_'), is_admin_callback=True)
    async def toggle_payment_method(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        method = callback_query.data.split('_')[2]
        methods = db.settings["payment_methods"]
        
        if method in methods:
            methods.remove(method)
        else:
            methods.append(method)
        
        db.save()
        
        # Update the message with new status
        methods_text = "💰 <b>Способы оплаты</b>\n\n"
        
        if "crypto" in methods:
            crypto_status = "✅ Включено" if db.settings.get("crypto_bot_token") else "❌ Выключено"
            methods_text += f"🔹 Crypto: {crypto_status}\n"
        
        markup = InlineKeyboardMarkup()
        
        # Toggle buttons for each method
        markup.add(InlineKeyboardButton(
            "🔄 Изменить Crypto", callback_data="toggle_method_crypto"
        ))
        
        await bot.send_message(
            callback_query.from_user.id,
            safe_html(methods_text),
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )


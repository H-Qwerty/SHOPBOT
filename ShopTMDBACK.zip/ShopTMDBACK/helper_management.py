from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ParseMode, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

from database import db
from keyboards import get_admin_keyboard, get_helper_management_keyboard
from states import AdminStates
from utils import safe_html
from config import ADMIN_IDS, HELPER_IDS

def register_helper_handlers(dp, bot):
    @dp.message_handler(Text(equals="👨‍💼 Управление помощниками"), is_admin=True)
    async def helper_management(message: types.Message):
        await message.answer(
            safe_html("👨‍💼 <b>Управление помощниками</b>\n\n"
            f"Текущие помощники: {len(HELPER_IDS)}\n\n"
            "Выберите действие из меню ниже:"),
            reply_markup=get_helper_management_keyboard(),
            parse_mode=ParseMode.HTML
        )

    @dp.message_handler(Text(equals="➕ Добавить помощника"), is_admin=True)
    async def add_helper_start(message: types.Message):
        await AdminStates.add_helper.set()
        
        await message.answer(
            safe_html("➕ <b>Добавить помощника</b>\n\n"
            "Пожалуйста, введите ID пользователя, которого вы хотите сделать помощником:"),
            parse_mode=ParseMode.HTML
        )

    @dp.message_handler(state=AdminStates.add_helper, is_admin=True)
    async def process_add_helper(message: types.Message, state: FSMContext):
        # First check if the message is "🔙 Назад в Админ меню"
        if message.text == "🔙 Назад в Админ меню":
            await state.finish()
            await message.answer(
                "🔙 Возврат в меню администратора.",
                reply_markup=get_admin_keyboard()
            )
            return
        
        try:
            helper_id = int(message.text.strip())
            
            # Check if user exists in the database
            if str(helper_id) not in db.users:
                await message.answer("❌ Пользователь не найден в базе данных. Пожалуйста, убедитесь, что пользователь начал диалог с ботом.")
                return
            
            # Check if user is already an admin
            if helper_id in ADMIN_IDS:
                await message.answer("❌ Этот пользователь уже является администратором.")
                return
            
            # Check if user is already a helper
            if helper_id in HELPER_IDS:
                await message.answer("❌ Этот пользователь уже является помощником.")
                return
            
            # Add user to helpers
            HELPER_IDS.append(helper_id)
            
            # Save to config or database
            # This depends on how you're storing HELPER_IDS
            # For example, if it's in the database settings:
            if "helpers" not in db.settings:
                db.settings["helpers"] = []
            
            if helper_id not in db.settings["helpers"]:
                db.settings["helpers"].append(helper_id)
                db.save()
            
            user = db.users[str(helper_id)]
            user_name = user.get('first_name', 'Unknown')
            
            await message.answer(
                safe_html(f"✅ Пользователь {user_name} (ID: <code>{helper_id}</code>) успешно добавлен как помощник."),
                reply_markup=get_helper_management_keyboard(),
                parse_mode=ParseMode.HTML
            )
            
            # Notify the user that they've been made a helper
            try:
                await bot.send_message(
                    helper_id,
                    safe_html("🎉 <b>Поздравляем!</b>\n\n"
                    "Вы были назначены помощником администратора. Теперь у вас есть доступ к дополнительным функциям бота."),
                    parse_mode=ParseMode.HTML
                )
            except Exception as e:
                import logging
                logging.error(f"Failed to notify new helper: {e}")
            
            await state.finish()
            
        except ValueError:
            await message.answer("❌ Пожалуйста, введите корректный ID пользователя (только цифры).")

    @dp.message_handler(Text(equals="🔙 Назад в Админ меню"), state=AdminStates.add_helper, is_admin=True)
    async def cancel_add_helper(message: types.Message, state: FSMContext):
        await state.finish()
        await message.answer(
            "🔙 Возврат в меню администратора.",
            reply_markup=get_admin_keyboard()
        )

    @dp.message_handler(Text(equals="➖ Удалить помощника"), is_admin=True)
    async def remove_helper_start(message: types.Message):
        if not HELPER_IDS:
            await message.answer("❌ Нет помощников для удаления.", reply_markup=get_helper_management_keyboard())
            return
        
        await AdminStates.remove_helper.set()
        
        markup = InlineKeyboardMarkup()
        for helper_id in HELPER_IDS:
            user_name = "Unknown"
            if str(helper_id) in db.users:
                user_name = db.users[str(helper_id)].get('first_name', 'Unknown')
            
            markup.add(InlineKeyboardButton(f"{user_name} (ID: {helper_id})", callback_data=f"remove_helper_{helper_id}"))
        
        await message.answer(
            safe_html("➖ <b>Удалить помощника</b>\n\n"
            "Пожалуйста, выберите помощника для удаления:"),
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )

    @dp.callback_query_handler(lambda c: c.data.startswith('remove_helper_'), state=AdminStates.remove_helper)
    async def process_remove_helper(callback_query: types.CallbackQuery, state: FSMContext):
        await bot.answer_callback_query(callback_query.id)
        
        helper_id = int(callback_query.data.replace("remove_helper_", ""))
        
        if helper_id not in HELPER_IDS:
            await bot.send_message(callback_query.from_user.id, "❌ Помощник не найден.")
            await state.finish()
            return
        
        # Remove user from helpers
        HELPER_IDS.remove(helper_id)
        
        # Save to config or database
        if "helpers" in db.settings and helper_id in db.settings["helpers"]:
            db.settings["helpers"].remove(helper_id)
            db.save()
        
        user_name = "Unknown"
        if str(helper_id) in db.users:
            user_name = db.users[str(helper_id)].get('first_name', 'Unknown')
        
        await bot.send_message(
            callback_query.from_user.id,
            safe_html(f"✅ Пользователь {user_name} (ID: <code>{helper_id}</code>) успешно удален из помощников."),
            reply_markup=get_helper_management_keyboard(),
            parse_mode=ParseMode.HTML
        )
        
        # Notify the user that they've been removed as a helper
        try:
            await bot.send_message(
                helper_id,
                safe_html("ℹ️ <b>Уведомление</b>\n\n"
                "Вы были удалены из списка помощников администратора."),
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            import logging
            logging.error(f"Failed to notify removed helper: {e}")
        
        await state.finish()

    @dp.message_handler(Text(equals="🔙 Назад в Админ меню"), state=AdminStates.remove_helper, is_admin=True)
    async def cancel_remove_helper(message: types.Message, state: FSMContext):
        await state.finish()
        await message.answer(
            "🔙 Возврат в меню администратора.",
            reply_markup=get_admin_keyboard()
        )

    @dp.message_handler(Text(equals="📋 Список помощников"), is_admin=True)
    async def list_helpers(message: types.Message):
        if not HELPER_IDS:
            await message.answer("❌ Нет помощников в списке.", reply_markup=get_helper_management_keyboard())
            return
        
        helpers_text = "📋 <b>Список помощников</b>\n\n"
        
        for helper_id in HELPER_IDS:
            user_name = "Unknown"
            username = "None"
            
            if str(helper_id) in db.users:
                user = db.users[str(helper_id)]
                user_name = user.get('first_name', 'Unknown')
                username = user.get('username', 'None')
            
            helpers_text += f"👤 {user_name} (ID: <code>{helper_id}</code>)"
            if username != 'None':
                helpers_text += f", @{username}"
            helpers_text += "\n"
        
        await message.answer(
            safe_html(helpers_text),
            reply_markup=get_helper_management_keyboard(),
            parse_mode=ParseMode.HTML
        )

    @dp.message_handler(Text(equals="🔙 Назад в Админ меню"), is_admin=True)
    async def back_to_admin_menu(message: types.Message):
        await message.answer(
            "🔙 Возврат в меню администратора.",
            reply_markup=get_admin_keyboard()
        )


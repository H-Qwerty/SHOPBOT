from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from database import is_admin, format_currency

# Main keyboards
def get_main_keyboard(user_id):
    """Create main keyboard based on user type"""
    from config import ADMIN_IDS, HELPER_IDS
    
    if user_id in ADMIN_IDS:
        keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
        keyboard.add(KeyboardButton("👤 Мой Профиль"))
        keyboard.add(KeyboardButton("🛒 Каталог"), KeyboardButton("❓ FAQ"))
        keyboard.add(KeyboardButton("⚙️ Админ панель"))
        return keyboard
    elif user_id in HELPER_IDS:
        keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
        keyboard.add(KeyboardButton("👤 Мой Профиль"))
        keyboard.add(KeyboardButton("🛒 Каталог"), KeyboardButton("❓ FAQ"))
        keyboard.add(KeyboardButton("👨‍💼 Панель помощника"))
        return keyboard
    else:
        keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
        keyboard.add(KeyboardButton("👤 Мой Профиль"))
        keyboard.add(KeyboardButton("🛒 Каталог"), KeyboardButton("❓ FAQ"))
        keyboard.add(KeyboardButton("🆘 Поддержка"))
        return keyboard

def get_admin_keyboard():
    """Create admin panel keyboard"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("⚙️ Настройки"))
    keyboard.add(KeyboardButton("👥 Управление пользователями"), KeyboardButton("🧾 Управление чеками"))
    keyboard.add(KeyboardButton("📦 Управление товарми"), KeyboardButton("📊 Статистика"))
    keyboard.add(KeyboardButton("📨 Рассылка"), KeyboardButton("💰 Способы оплаты"))
    keyboard.add(KeyboardButton("👨‍💼 Управление помощниками"))  # Add helper management button
    keyboard.add(KeyboardButton("🔙 Назад в меню"))
    return keyboard

def get_settings_keyboard():
    """Create settings keyboard"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("📝 Изменить FAQ"), KeyboardButton("👨‍💻 Изменить Поддержку"))
    keyboard.add(KeyboardButton("🔌 Тех.Работы"), KeyboardButton("🛒 Изменить покупки"))
    keyboard.add(KeyboardButton("💰 Пополнения баланса"), KeyboardButton("🔑 Crypto Bot токен"))
    keyboard.add(KeyboardButton("🔙 Назад в Админ меню"))
    return keyboard

def get_product_management_keyboard():
    """Create product management keyboard"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("➕ Создать категорию"), KeyboardButton("✏️ Редактировать категорию"))
    keyboard.add(KeyboardButton("🗑️ Удалить категории"))
    keyboard.add(KeyboardButton("➕ Создать позицию"), KeyboardButton("✏️ Редактировать позицию"))
    keyboard.add(KeyboardButton("🗑️ Удалить все позиции"))
    keyboard.add(KeyboardButton("➕ Добавить товары"), KeyboardButton("🗑️ Удалить товар"))
    keyboard.add(KeyboardButton("🗑️ Удалить все товары"))
    keyboard.add(KeyboardButton("🔙 Назад в Админ меню"))
    return keyboard

def get_user_management_keyboard():
    """Create user management keyboard"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("🔍 Искать профиль"))
    keyboard.add(KeyboardButton("🔙 Назад в Админ меню"))
    return keyboard

def get_receipt_management_keyboard():
    """Create receipt management keyboard"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("🔍 Искать чек"))
    keyboard.add(KeyboardButton("🔙 Назад в Админ меню"))
    return keyboard

def get_helper_keyboard():
    """Create helper panel keyboard"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("📦 Управление товарми"))
    keyboard.add(KeyboardButton("📊 Статистика"))
    keyboard.add(KeyboardButton("📨 Рассылка"))
    keyboard.add(KeyboardButton("🔌 Тех.Работы"))
    keyboard.add(KeyboardButton("🔙 Назад в меню"))
    return keyboard

def get_helper_management_keyboard():
    """Create helper management keyboard"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("➕ Добавить помощника"))
    keyboard.add(KeyboardButton("➖ Удалить помощника"))
    keyboard.add(KeyboardButton("📋 Список помощников"))
    keyboard.add(KeyboardButton("🔙 Назад в Админ меню"))
    return keyboard

# Inline keyboards
def get_profile_inline_keyboard():
    """Create profile inline keyboard"""
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("💰 Пополнить баланс", callback_data="topup_balance"))
    markup.add(InlineKeyboardButton("🛒 Мои покупки", callback_data="my_purchases"))
    return markup

def get_categories_inline_keyboard(db):
    """Create categories inline keyboard"""
    markup = InlineKeyboardMarkup()
    for category_id, category in db.categories.items():
        markup.add(InlineKeyboardButton(category["name"], callback_data=f"category_{category_id}"))
    return markup

def get_positions_inline_keyboard(db, category_id):
    """Create positions inline keyboard for a category"""
    markup = InlineKeyboardMarkup()
    positions = [pos for pos_id, pos in db.positions.items() if pos["category_id"] == category_id]
    
    for position in positions:
        markup.add(InlineKeyboardButton(
            f"{position['name']} - {format_currency(position['price'])}", 
            callback_data=f"position_{position['id']}"
        ))
    
    markup.add(InlineKeyboardButton("🔙 Назад к категориям", callback_data="back_to_categories"))
    return markup

def get_payment_methods_inline_keyboard(payment_methods):
    """Create payment methods inline keyboard"""
    markup = InlineKeyboardMarkup()
    for method in payment_methods:
        markup.add(InlineKeyboardButton(method.capitalize(), callback_data=f"payment_method_{method}"))
    return markup

def get_confirm_payment_inline_keyboard():
    """Create confirm payment inline keyboard"""
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("✅ Продолжить", callback_data="confirm_payment"))
    markup.add(InlineKeyboardButton("❌ Отменить", callback_data="cancel_payment"))
    return markup


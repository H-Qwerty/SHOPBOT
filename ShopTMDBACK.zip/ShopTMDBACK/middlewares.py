import logging
from datetime import datetime, timedelta
from aiogram import types
from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware
from database import db
from config import ADMIN_IDS  # Добавляем импорт ADMIN_IDS

class AntiSpamMiddleware(BaseMiddleware):
    """
    Middleware to prevent spam
    """
    def __init__(self, rate_limit=10, rate_period=3):
        """
        Initialize middleware
        :param rate_limit: Maximum number of messages allowed in rate_period
        :param rate_period: Time period in seconds
        """
        self.rate_limit = rate_limit
        self.rate_period = rate_period
        self.user_messages = {}
        self.banned_users = {}
        super(AntiSpamMiddleware, self).__init__()
    
    async def on_process_message(self, message: types.Message, data: dict):
        """
        Process message and check for spam
        """
        # Skip checks for admin users
        if message.from_user.id in ADMIN_IDS:  # Используем ADMIN_IDS напрямую
            return
        
        user_id = message.from_user.id
        current_time = datetime.now()
        

        if user_id in self.banned_users:
            ban_until = self.banned_users[user_id]
            if current_time < ban_until:
                remaining_time = (ban_until - current_time).seconds
                await message.answer(f"⛔ Вы временно заблокированы за спам. Повторите попытку через {remaining_time} секунд.")
                raise CancelHandler()
            else:

                del self.banned_users[user_id]
        

        if user_id not in self.user_messages:
            self.user_messages[user_id] = []
        

        cutoff_time = current_time - timedelta(seconds=self.rate_period)
        self.user_messages[user_id] = [
            msg_time for msg_time in self.user_messages[user_id] 
            if msg_time > cutoff_time
        ]
        

        self.user_messages[user_id].append(current_time)
        

        if len(self.user_messages[user_id]) > self.rate_limit:

            ban_count = getattr(self, f"ban_count_{user_id}", 0) + 1
            setattr(self, f"ban_count_{user_id}", ban_count)
            

            ban_duration = min(2 * ban_count, 300)
            ban_until = current_time + timedelta(seconds=ban_duration)
            self.banned_users[user_id] = ban_until
            
            await message.answer(f"⛔ Обнаружен спам! Вы временно заблокированы на {ban_duration} секунд.")
            logging.warning(f"User {user_id} banned for spam for {ban_duration} seconds")
            raise CancelHandler()
        
        # Update user's last activity
        db.update_user_activity(user_id)

class UpdateUserActivityMiddleware(BaseMiddleware):
    """
    Middleware to update user's last activity timestamp
    """
    async def on_process_message(self, message: types.Message, data: dict):
        """
        Update user's last activity on each message
        """
        db.update_user_activity(message.from_user.id)
    
    async def on_process_callback_query(self, callback_query: types.CallbackQuery, data: dict):
        """
        Update user's last activity on each callback query
        """
        db.update_user_activity(callback_query.from_user.id)
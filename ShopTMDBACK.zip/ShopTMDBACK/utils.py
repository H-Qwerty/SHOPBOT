import re
import html

def safe_html(text):
    """
    Sanitize HTML to prevent errors when sending messages with ParseMode.HTML
    """
    if not text:
        return ""
    
    text = html.escape(text)
    
    allowed_tags = {
        '&lt;b&gt;': '<b>', '&lt;/b&gt;': '</b>',
        '&lt;i&gt;': '<i>', '&lt;/i&gt;': '</i>',
        '&lt;u&gt;': '<u>', '&lt;/u&gt;': '</u>',
        '&lt;s&gt;': '<s>', '&lt;/s&gt;': '</s>',
        '&lt;code&gt;': '<code>', '&lt;/code&gt;': '</code>',
        '&lt;pre&gt;': '<pre>', '&lt;/pre&gt;': '</pre>',
        '&lt;a href=': '<a href=',
        '&lt;/a&gt;': '</a>'
    }
    
    for escaped, original in allowed_tags.items():
        text = text.replace(escaped, original)
    
    tags = ['b', 'i', 'u', 's', 'code', 'pre']
    for tag in tags:
        open_count = text.count(f'<{tag}>')
        close_count = text.count(f'</{tag}>')
        
        if open_count > close_count:
            text += f'</{tag}>' * (open_count - close_count)
    
    a_open_count = len(re.findall(r'<a href=', text))
    a_close_count = text.count('</a>')
    
    if a_open_count > a_close_count:
        text += '</a>' * (a_open_count - a_close_count)
    
    return text

def format_html_message(message_template, **kwargs):
    """
    Format a message template with variables, ensuring HTML safety
    """
    safe_kwargs = {k: safe_html(str(v)) for k, v in kwargs.items()}
    
    try:
        formatted_message = message_template.format(**safe_kwargs)
        return formatted_message
    except KeyError as e:

        return f"Error in message template: Missing key {e}"
    except Exception as e:

        return f"Error in message template: {e}"


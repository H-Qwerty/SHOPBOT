from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ParseMode, InlineKeyboardMarkup, InlineKeyboardButton

from database import db, format_currency, is_admin
from keyboards import get_main_keyboard, get_profile_inline_keyboard, get_categories_inline_keyboard, get_helper_keyboard
from states import UserStates
from utils import safe_html
import logging
from datetime import datetime
from config import ADMIN_IDS, HELPER_IDS  # Add this import


def register_user_handlers(dp, bot):

    @dp.message_handler(commands=['start'])
    async def cmd_start(message: types.Message):
        user_id = message.from_user.id
        

        if db.settings["maintenance_mode"] and not is_admin(user_id) and user_id not in HELPER_IDS:
            await message.answer("🛠️ Бот сейчас на техническом обслуживании. Пожалуйста, повторите попытку позже.")
            return
        

        db.register_user(user_id, message.from_user.username, message.from_user.first_name)
        

        if not db.settings.get("bot_username"):
            bot_info = await bot.get_me()
            db.settings["bot_username"] = bot_info.username
            db.save()
        
        await message.answer(
            f"👋 Добро пожаловать в магазин Физ.Номеров, {message.from_user.first_name}!\n\n"
            "Используйте меню , чтобы начать пользоваться ботом.",
            reply_markup=get_main_keyboard(user_id)
        )


    @dp.message_handler(Text(equals="👤 Мой Профиль"))
    async def show_profile(message: types.Message):
        user_id = str(message.from_user.id)
        

        if user_id not in db.users:
            db.register_user(message.from_user.id, message.from_user.username, message.from_user.first_name)
        
        user = db.users[user_id]
        
        profile_text = (
            f"👤 <b>Ваш профиль</b>\n\n"
            f"🆔 ID: <code>{user['id']}</code>\n"
            f"👤 Имя: {user['first_name']}\n"
        )
        
        if user['username']:
            profile_text += f"🔤 Username: @{user['username']}\n"
        
        profile_text += (
            f"💰 Баланс: {format_currency(user['balance'])}\n"
            f"🛒 Покупки: {len(user['purchases'])}\n"
            f"📅 Присоеденились: {user['join_date']}"
        )
        
        await message.answer(profile_text, reply_markup=get_profile_inline_keyboard(), parse_mode=ParseMode.HTML)


    @dp.message_handler(Text(equals="🛒 Каталог"))
    async def show_catalog(message: types.Message):
        user_id = message.from_user.id
        

        if db.settings["purchases_enabled"] == False and not is_admin(user_id):
            await message.answer("🔒 Покупки были временно отключены Администратором.")
            return
        
        if not db.categories:
            await message.answer("😢 На данный момент в наличии нет продуктов. Пожалуйста, зайдите позже.")
            return
        
        await message.answer(
            "🛒 <b>Категории продуктов</b>\n\nПожалуйста, выберите категорию:", 
            reply_markup=get_categories_inline_keyboard(db), 
            parse_mode=ParseMode.HTML
        )


    @dp.message_handler(Text(equals="❓ FAQ"))
    async def show_faq(message: types.Message):

        faq_text = db.settings["faq"]
        faq_text = faq_text.replace("{id}", str(message.from_user.id))
        faq_text = faq_text.replace("{name}", message.from_user.first_name)
        faq_text = faq_text.replace("{username}", message.from_user.username or "")
        
        await message.answer(faq_text, parse_mode=ParseMode.HTML)


    @dp.message_handler(Text(equals="🆘 Поддержка"))
    async def show_support(message: types.Message):
        if not db.settings["support_id"]:
            await message.answer("😢 Поддержка еще не настроена. Пожалуйста, повторите попытку позже.")
            return
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("✍️ Напишите ваше обращение к поддержке", callback_data="write_support"))
        
        await message.answer(
            "🆘 <b>Поддержка</b>\n\n"
            "Если у вас есть какие-либо вопросы или проблемы, наша служба поддержки всегда готова помочь!",
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )


    @dp.callback_query_handler(lambda c: c.data == "write_support")
    async def write_support_start(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        await UserStates.write_support_message.set()
        
        await bot.send_message(
            callback_query.from_user.id,
            "✍️ <b>Написать поддержке</b>\n\n"
            "Пожалуйста, введите ваше сообщение в службу поддержки. Будьте максимально подробны:",
            parse_mode=ParseMode.HTML
        )

    @dp.message_handler(state=UserStates.write_support_message)
    async def process_support_message(message: types.Message, state: FSMContext):
        support_message = message.text
        
        if not db.settings["support_id"]:
            await message.answer("❌ Поддержка не настроена. Ваше сообщение не может быть доставлено.")
            await state.finish()
            return
        

        try:
            await bot.send_message(
                db.settings["support_id"],
                f"📨 <b>Обращение</b>\n\n"
                f"От: {message.from_user.first_name} (ID: {message.from_user.id})\n"
                f"Username: @{message.from_user.username or 'None'}\n\n"
                f"Текст обращения:\n{support_message}",
                parse_mode=ParseMode.HTML
            )
            
            await message.answer(
                "✅ Ваше сообщение отправлено в поддержку. Они скоро свяжутся с вами."
            )
        except Exception as e:
            import logging
            logging.error(f"Failed to send support message: {e}")
            await message.answer("❌ Не удалось отправить сообщение в службу поддержки. Пожалуйста, повторите попытку позже.")
        
        await state.finish()

    # View purchases
    @dp.callback_query_handler(lambda c: c.data == "my_purchases")
    async def show_purchases(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        user_id = str(callback_query.from_user.id)
        user = db.users[user_id]
        
        if not user["purchases"]:
            await bot.send_message(callback_query.from_user.id, "😢 Вы еще не совершили ни одной покупки.")
            return
        
        purchases_text = "🛒 <b>Мои покупки</b>\n\n"
        
        for receipt_id in user["purchases"][-5:]:  # Show last 5 purchases
            if receipt_id in db.receipts:
                receipt = db.receipts[receipt_id]
                purchases_text += (
                    f"🧾 Чек: <code>{receipt_id}</code>\n"
                    f"📦 Продукт: {receipt['product_name']}\n"
                    f"💰 Цена: {format_currency(receipt['amount'])}\n"
                    f"📅 Дата: {receipt['date']}\n\n"
                )
        
        await bot.send_message(
            callback_query.from_user.id,
            purchases_text,
            parse_mode=ParseMode.HTML
        )

    # Top up balance
    @dp.callback_query_handler(lambda c: c.data == "topup_balance")
    async def topup_balance(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        user_id = callback_query.from_user.id
        
        # Check if top-ups are disabled
        if db.settings["topup_enabled"] == False and not is_admin(user_id):
            await bot.send_message(user_id, "🔒 Пополнение баланса временно отключено администратором..")
            return
        
        # For Crypto Bot, we'll show predefined amounts or allow custom amount
        markup = InlineKeyboardMarkup(row_width=3)
        
        # Add predefined amounts
        markup.add(
            InlineKeyboardButton("$5", callback_data="crypto_amount_5"),
            InlineKeyboardButton("$10", callback_data="crypto_amount_10"),
            InlineKeyboardButton("$20", callback_data="crypto_amount_20")
        )
        
        markup.add(
            InlineKeyboardButton("$50", callback_data="crypto_amount_50"),
            InlineKeyboardButton("$100", callback_data="crypto_amount_100"),
            InlineKeyboardButton("$200", callback_data="crypto_amount_200")
        )
        
        markup.add(InlineKeyboardButton("💰 Своя сумма", callback_data="crypto_amount_custom"))
        
        await bot.send_message(
            user_id,
            "💰 <b>Пополнить Баланс</b>\n\n"
            "Пожалуйста, выберите сумму или введите произвольную сумму",
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )

    # Handle predefined crypto amounts
    @dp.callback_query_handler(lambda c: c.data.startswith('crypto_amount_') and c.data != 'crypto_amount_custom')
    async def process_crypto_predefined_amount(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        # Extract amount from callback data
        amount_str = callback_query.data.split('_')[2]
        amount = float(amount_str)
        
        # Create invoice
        await create_crypto_invoice(callback_query.from_user.id, amount, bot)

    # Handle custom crypto amount
    @dp.callback_query_handler(lambda c: c.data == 'crypto_amount_custom')
    async def crypto_custom_amount(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        await UserStates.enter_crypto_amount.set()
        
        await bot.send_message(
            callback_query.from_user.id,
            "💰 <b>Своя сумма</b>\n\n"
            "Пожалуйста, введите сумму, которую вы хотите пополнить (в USD):",
            parse_mode=ParseMode.HTML
        )

    @dp.message_handler(state=UserStates.enter_crypto_amount)
    async def process_crypto_custom_amount(message: types.Message, state: FSMContext):
        try:
            amount = float(message.text.strip())
            
            if amount <= 0:
                await message.answer("❌ Сумма должна быть больше нуля. Пожалуйста, попробуйте еще раз.")
                return
            
            # Clear state
            await state.finish()
            
            # Create invoice
            await create_crypto_invoice(message.from_user.id, amount, bot)
            
        except ValueError:
            await message.answer("❌ Пожалуйста, введите действительный номер.")

    # Check payment status
# In user_menu.py

    @dp.callback_query_handler(lambda c: c.data.startswith('check_payment_'))
    async def check_payment(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        invoice_id = callback_query.data.split('_')[2]
        user_id = callback_query.from_user.id
        
        # Check invoice status
        invoice = db.check_invoice_status(invoice_id)
        
        if not invoice:
            await bot.send_message(
                user_id,
                safe_html("❌ <b>Error</b>\n\nНе удалось проверить статус счета. Пожалуйста, повторите попытку позже или обратитесь в службу поддержки."),
                parse_mode=ParseMode.HTML
            )
            return
        
        status = invoice.get('status')
        
        if status == 'paid':
            # Find the receipt with this invoice_id
            receipt_id = None
            for rid, receipt in db.receipts.items():
                if receipt.get('type') == 'topup' and receipt.get('payment_method') == 'crypto':
                    details = receipt.get('details', {})
                    if details.get('invoice_id') == int(invoice_id) and receipt.get('status') == 'pending':
                        receipt_id = rid
                        break
            
            if not receipt_id:
                await bot.send_message(
                    user_id,
                    safe_html("❌ <b>Error</b>\n\nЧек не найден. обратитесь в службу поддержки."),
                    parse_mode=ParseMode.HTML
                )
                return
            
            # Update receipt status
            db.receipts[receipt_id]['status'] = 'completed'
            
            # Add amount to user balance
            amount = db.receipts[receipt_id]['amount']
            db.users[str(user_id)]['balance'] += amount
            
            # Update stats
            db.stats['total_topups'] += 1
            db.stats['total_user_balance'] += amount
            
            # Save database
            db.save()
            
            await bot.send_message(
                user_id,
                safe_html(f"✅ <b>Платеж успешен!</b>\n\n"
                f"Ваш платеж {format_currency(amount)} был получен и ваш баланс обновлен.\n\n"
                f"Ваш новый баланс: {format_currency(db.users[str(user_id)]['balance'])}"),
                parse_mode=ParseMode.HTML
            )
        elif status == 'active':
            await bot.send_message(
                user_id,
                safe_html("⏳ <b>Ожидается платеж</b>\n\n"
                "Ваш платеж еще не получен. Пожалуйста, завершите платеж и попробуйте проверить еще раз.."),
                parse_mode=ParseMode.HTML
            )
        else:
            await bot.send_message(
                user_id,
                safe_html(f"❌ <b>Ошибка платежа</b>\n\n"
                f"Статус платежа: {status}\n\n"
                f"Пожалуйста, попробуйте еще раз или обратитесь в службу поддержки."),
                parse_mode=ParseMode.HTML
            )

    @dp.callback_query_handler(lambda c: c.data.startswith('check_payment_'))
    async def check_payment(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        invoice_id = callback_query.data.split('_')[2]
        user_id = callback_query.from_user.id
        
        # Check invoice status
        invoice = db.check_invoice_status(invoice_id)
        
        if not invoice:
            await bot.send_message(
                user_id,
                safe_html("❌ <b>Error</b>\n\nНе удалось проверить статус счета. Пожалуйста, повторите попытку позже или обратитесь в службу поддержки."),
                parse_mode=ParseMode.HTML
            )
            return
        
        status = invoice.get('status')
        
        if status == 'paid':
            # Find the receipt with this invoice_id
            receipt_id = None
            for rid, receipt in db.receipts.items():
                if receipt.get('type') == 'topup' and receipt.get('payment_method') == 'crypto':
                    details = receipt.get('details', {})
                    if details.get('invoice_id') == int(invoice_id) and receipt.get('status') == 'pending':
                        receipt_id = rid
                        break
            
            if not receipt_id:
                await bot.send_message(
                    user_id,
                    safe_html("❌ <b>Error</b>\n\nЧек не найден. Пожалуйста, свяжитесь со службой поддержки."),
                    parse_mode=ParseMode.HTML
                )
                return
            
            # Update receipt status
            db.receipts[receipt_id]['status'] = 'completed'
            
            # Add amount to user balance
            amount = db.receipts[receipt_id]['amount']
            db.users[str(user_id)]['balance'] += amount
            
            # Update stats
            db.stats['total_topups'] += 1
            db.stats['total_user_balance'] += amount
            
            # Save database
            db.save()
            
            await bot.send_message(
                user_id,
                safe_html(f"✅ <b>Платеж успешен!</b>\n\n"
                f"Ваш платеж {format_currency(amount)} был получен и ваш баланс обновлен.\n\n"
                f"Ваш баланс: {format_currency(db.users[str(user_id)]['balance'])}"),
                parse_mode=ParseMode.HTML
            )
        elif status == 'active':
            await bot.send_message(
                user_id,
                safe_html("⏳ <b>Ожидается платеж</b>\n\n"
                "Ваш платеж еще не получен. Пожалуйста, завершите платеж и попробуйте проверить еще раз."),
                parse_mode=ParseMode.HTML
            )
        else:
            await bot.send_message(
                user_id,
                safe_html(f"❌ <b>Ошибка платежа</b>\n\n"
                f"Статус платежа: {status}\n\n"
                f"Пожалуйста, попробуйте еще раз или обратитесь в службу поддержки.."),
                parse_mode=ParseMode.HTML
            )

    # Category and product navigation
    @dp.callback_query_handler(lambda c: c.data.startswith('category_'))
    async def process_category_selection(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        # The problem is here - we need to get everything after "category_"
        # Instead of just splitting by underscore which doesn't work if category IDs contain underscores
        category_id = callback_query.data.replace("category_", "")
        
        if category_id not in db.categories:
            # Add logging to help debug the issue
            logging.error(f"Category not found: {category_id}")
            logging.error(f"Available categories: {list(db.categories.keys())}")
            await bot.send_message(callback_query.from_user.id, "❌ Категория не найдена.")
            return
        
        category = db.categories[category_id]
        
        # Get positions in this category
        positions = [pos for pos_id, pos in db.positions.items() if pos["category_id"] == category_id]
        
        if not positions:
            await bot.send_message(
                callback_query.from_user.id,
                f"😢 В наличии нет товаров '{category['name']}' в данной категории."
            )
            return
        
        markup = InlineKeyboardMarkup()
        for position in positions:
            markup.add(InlineKeyboardButton(
                f"{position['name']} - {format_currency(position['price'])}", 
                callback_data=f"position_{position['id']}"
            ))
        
        markup.add(InlineKeyboardButton("🔙 Назад к категориям", callback_data="back_to_categories"))
        
        await bot.send_message(
            callback_query.from_user.id,
            f"📂 <b>{category['name']}</b>\n\nPlease select a product:",
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )

    @dp.callback_query_handler(lambda c: c.data == "back_to_categories")
    async def back_to_categories(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        await bot.send_message(
            callback_query.from_user.id,
            "🛒 <b>Product Categories</b>\n\nPlease select a category:",
            reply_markup=get_categories_inline_keyboard(db),
            parse_mode=ParseMode.HTML
        )

    @dp.callback_query_handler(lambda c: c.data.startswith('position_'))
    async def process_position_selection(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        # Fix the same issue here - get everything after "position_"
        position_id = callback_query.data.replace("position_", "")
        
        if position_id not in db.positions:
            # Add logging
            logging.error(f"Position not found: {position_id}")
            logging.error(f"Available positions: {list(db.positions.keys())}")
            await bot.send_message(callback_query.from_user.id, "❌ Товар не найден.")
            return
        
        position = db.positions[position_id]
        category = db.categories[position["category_id"]]
        
        # Count available products
        available_products = [prod for prod_id, prod in db.products.items() if prod["position_id"] == position_id]
        product_count = len(available_products)
        
        position_text = (
            f"📦 <b>{position['name']}</b>\n\n"
            f"💰 Цена: {format_currency(position['price'])}\n"
            f"📝 Описание: {position['description']}\n"
            f"📂 Категория: {category['name']}\n"
            f"🏷️ Наличие: {product_count} шт."
        )
        
        markup = InlineKeyboardMarkup()
        
        if product_count > 0 and db.settings["purchases_enabled"]:
            markup.add(InlineKeyboardButton("🛒 Купить", callback_data=f"buy_{position_id}"))
        
        markup.add(InlineKeyboardButton("🔙 Назад к категориям", callback_data=f"category_{category['id']}"))
        
        # If position has an image, send it with the message
        if position.get("image_url"):
            await bot.send_photo(
                callback_query.from_user.id,
                photo=position["image_url"],
                caption=position_text,
                reply_markup=markup,
                parse_mode=ParseMode.HTML
            )
        else:
            await bot.send_message(
                callback_query.from_user.id,
                position_text,
                reply_markup=markup,
                parse_mode=ParseMode.HTML
            )

    @dp.callback_query_handler(lambda c: c.data.startswith('buy_'))
    async def process_buy(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        
        user_id = str(callback_query.from_user.id)
        # Fix the same issue here - get everything after "buy_"
        position_id = callback_query.data.replace("buy_", "")
        
        if position_id not in db.positions:
            # Add logging
            logging.error(f"Position not found during purchase: {position_id}")
            logging.error(f"Available positions: {list(db.positions.keys())}")
            await bot.send_message(callback_query.from_user.id, "❌ Товар не найден.")
            return
        
        position = db.positions[position_id]
        category = db.categories[position["category_id"]]
        
        # Rest of the function remains the same...
        # Check if user has enough balance
        if db.users[user_id]["balance"] < position["price"]:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("💰 Пополнить баланс", callback_data="topup_balance"))
            
            await bot.send_message(
                callback_query.from_user.id,
                f"❌ Недостаточный баланс. Вам нужно {format_currency(position['price'])} ,но есть {format_currency(db.users[user_id]['balance'])}.",
                reply_markup=markup
            )
            return
        
        # Check if products are available
        available_products = [prod for prod_id, prod in db.products.items() if prod["position_id"] == position_id]
        
        if not available_products:
            await bot.send_message(callback_query.from_user.id, "❌ Данного товара нет в наличии.")
            return
        
        # Get the first available product
        product_id = available_products[0]["id"]
        product = db.products[product_id]
        
        # Process the purchase
        db.users[user_id]["balance"] -= position["price"]
        
        # Create receipt
        from datetime import datetime
        receipt_id = db.generate_receipt_id()
        db.receipts[receipt_id] = {
            "id": receipt_id,
            "user_id": int(user_id),
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "amount": position["price"],
            "type": "purchase",
            "product_id": product_id,
            "product_name": position["name"],
            "position_id": position_id,
            "position_name": position["name"],
            "category_id": category["id"],
            "category_name": category["name"],
            "status": "completed"
        }
        
        # Add purchase to user's history
        db.users[user_id]["purchases"].append(receipt_id)
        
        # Remove the product from inventory
        del db.products[product_id]
        
        # Update statistics
        db.stats["total_purchases"] += 1
        db.stats["total_products_sold"] += 1
        db.stats["total_revenue"] += position["price"]
        db.stats["total_user_balance"] -= position["price"]
        
        db.save()
        
        # Send purchase confirmation
        purchase_text = (
            f"✅ <b>Покупка успешна!</b>\n\n"
            f"🧾 Чек: <code>{receipt_id}</code>\n"
            f"📦 Товар: {position['name']}\n"
            f"💰 Цена: {format_currency(position['price'])}\n"
            f"📅 Дата: {db.receipts[receipt_id]['date']}\n\n"
            f"Ваш товар:\n<code>{product['content']}</code>\n\n"
            f"Ваш новый баланс: {format_currency(db.users[user_id]['balance'])}"
        )
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🛒 Продолжить покупки", callback_data="back_to_categories"))
        
        await bot.send_message(
            callback_query.from_user.id,
            purchase_text,
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )

    # Helper panel handler
    @dp.message_handler(Text(equals="👨‍💼 Панель помощника"), is_helper=True)
    async def helper_panel(message: types.Message):
        await message.answer(
            safe_html("👨‍💼 <b>Панель помощника</b>\n\n"
            "Добро пожаловать в панель помощника. Выберите опцию:"),
            reply_markup=get_helper_keyboard(),
            parse_mode=ParseMode.HTML
        )

    @dp.message_handler(Text(equals="🔙 Назад в меню"), is_helper=True)
    async def helper_back_to_main_menu(message: types.Message):
        await message.answer(
            "🔙 Возврат в главное меню.",
            reply_markup=get_main_keyboard(message.from_user.id)
        )

async def create_crypto_invoice(user_id, amount, bot):
    """Create a crypto invoice and send it to the user"""
    try:
        # Create invoice via Crypto Bot API
        invoice = db.create_crypto_invoice(user_id, amount)
        
        if not invoice:
            await bot.send_message(
                user_id,
                safe_html("❌ <b>Error</b>\n\nНе удалось создать счет. Пожалуйста, повторите попытку позже или обратитесь в службу поддержки."),
                parse_mode=ParseMode.HTML
            )
            return
        
        # Get the invoice_id from the response
        invoice_id = invoice.get('invoice_id')
        if not invoice_id:
            logging.error(f"Invoice object missing invoice_id: {invoice}")
            await bot.send_message(
                user_id,
                safe_html("❌ <b>Error</b>\n\nInvalid invoice data. Please try again later or contact support."),
                parse_mode=ParseMode.HTML
            )
            return
            
        # Get the payment URL
        pay_url = invoice.get('pay_url')
        if not pay_url:
            logging.error(f"В объекте счета отсутствует URL-адрес платежа: {invoice}")
            await bot.send_message(
                user_id,
                safe_html("❌ <b>Error</b>\n\nНеверные данные счета. Пожалуйста, повторите попытку позже или обратитесь в службу поддержки."),
                parse_mode=ParseMode.HTML
            )
            return
        
        # Create a receipt in the database
        # Since db.create_receipt doesn't exist, we'll create a receipt directly
        receipt_id = f"CRYPTO_{datetime.now().strftime('%Y%m%d%H%M%S')}_{user_id}"
        
        # Add the receipt to the user's receipts
        if str(user_id) not in db.users:
            logging.error(f"Пользователь {user_id} не найден в базе данных.")
            await bot.send_message(
                user_id,
                safe_html("❌ <b>Error</b>\n\nПользователь не найден. Пожалуйста, повторите попытку позже или обратитесь в службу поддержки."),
                parse_mode=ParseMode.HTML
            )
            return
            
        # Create the receipt in the database
        db.receipts[receipt_id] = {
            "user_id": user_id,
            "amount": amount,
            "type": "topup",
            "payment_method": "crypto",
            "status": "pending",
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "details": {
                "invoice_id": invoice_id,
                "pay_url": pay_url
            }
        }
        
        # Add receipt to user's receipts list
        if "receipts" not in db.users[str(user_id)]:
            db.users[str(user_id)]["receipts"] = []
        
        db.users[str(user_id)]["receipts"].append(receipt_id)
        
        # Save the database
        db.save()
        
        # Send invoice to user
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("💳 Оплатить", url=pay_url))
        # Use invoice_id instead of invoice['id']
        markup.add(InlineKeyboardButton("🔄 Проверить оплату", callback_data=f"check_payment_{invoice_id}"))
        
        await bot.send_message(
            user_id,
            safe_html(f"💰 <b>Криптовалютный платеж</b>\n\n"
            f"Сумма: {format_currency(amount)}\n"
            f"🧾 Счет: <code>{invoice_id}</code>\n"  # Use invoice_id instead of invoice['id']
            f"Чек ID: <code>{receipt_id}</code>\n\n"
            f"Пожалуйста, нажмите кнопку ниже, чтобы произвести оплату. После завершения оплаты нажмите «Проверить платеж», чтобы обновить баланс"),
            reply_markup=markup,
            parse_mode=ParseMode.HTML
        )
        
    except Exception as e:
        logging.error(f"Error for user {user_id}: {e}")
        await bot.send_message(
            user_id,
            safe_html("❌ <b>Error</b>\n\nПроизошла непредвиденная ошибка. Пожалуйста, повторите попытку позже или обратитесь в службу поддержки."),
            parse_mode=ParseMode.HTML
        )


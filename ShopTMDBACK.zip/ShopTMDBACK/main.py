import logging
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from config import BOT_TOKEN, HELPER_IDS, load_helpers_from_settings
from database import db
from filters import IsAdmin, IsAdminCallback, IsHelper, IsHelperCallback, IsAdminOrHelper, IsAdminOrHelperCallback
from middlewares import AntiSpamMiddleware, UpdateUserActivityMiddleware
from user_menu import register_user_handlers
from admin_menu import register_admin_handlers
from product_management import register_product_handlers
from helper_management import register_helper_handlers

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

# Register filters
dp.filters_factory.bind(IsAdmin)
dp.filters_factory.bind(IsAdminCallback)
dp.filters_factory.bind(IsHelper)
dp.filters_factory.bind(IsHelperCallback)
dp.filters_factory.bind(IsAdminOrHelper)
dp.filters_factory.bind(IsAdminOrHelperCallback)

# Setup middlewares
dp.middleware.setup(UpdateUserActivityMiddleware())
if db.settings["anti_spam"]["enabled"]:
    dp.middleware.setup(AntiSpamMiddleware(
        rate_limit=db.settings["anti_spam"]["rate_limit"],
        rate_period=db.settings["anti_spam"]["rate_period"]
    ))

# Register all handlers
register_user_handlers(dp, bot)
register_admin_handlers(dp, bot)
register_product_handlers(dp, bot)
register_helper_handlers(dp, bot)

# Error handler
@dp.errors_handler()
async def errors_handler(update, exception):
    """
    Handle errors
    """
    try:
        logging.exception(f"Exception: {exception}")
        
        # Get user ID if possible
        user_id = None
        if hasattr(update, 'message') and update.message:
            user_id = update.message.from_user.id
        elif hasattr(update, 'callback_query') and update.callback_query:
            user_id = update.callback_query.from_user.id
        
        # Log error with user info if available
        if user_id:
            logging.error(f"Error for user {user_id}: {exception}")
        
        # Notify user about error
        if user_id:
            await bot.send_message(
                user_id,
                "❌ Произошла ошибка при обработке вашего запроса. Пожалуйста, попробуйте еще раз позже."
            )
    except Exception as e:
        logging.exception(f"Exception in error handler: {e}")
    
    return True

# Main function to start the bot
async def main():
    # Ensure database directory exists
    import os
    from config import DB_FOLDER
    os.makedirs(DB_FOLDER, exist_ok=True)
    
    # Load helper IDs from settings
    load_helpers_from_settings()
    
    # Log bot startup
    logging.info("Starting bot...")
    logging.info(f"Helper IDs: {HELPER_IDS}")
    
    # Start the bot
    await dp.start_polling()

if __name__ == '__main__':
    # Run the bot
    asyncio.run(main())


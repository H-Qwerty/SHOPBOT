from aiogram.dispatcher.filters.state import State, StatesGroup

# Admin states
class AdminStates(StatesGroup):
    # Settings states
    change_faq = State()
    change_support = State()
    change_crypto_token = State()
    
    # User management states
    search_profile = State()
    change_balance = State()
    send_message = State()
    
    # Receipt management
    search_receipt = State()
    
    # Mass messaging
    broadcast_message = State()
    
    # Category management
    create_category = State()
    edit_category_select = State()
    edit_category_name = State()
    
    # Position management
    create_position_select_category = State()
    create_position_name = State()
    create_position_description = State()
    create_position_price = State()
    create_position_image = State()
    
    edit_position_select = State()
    edit_position_name = State()
    edit_position_description = State()
    edit_position_price = State()
    edit_position_image = State()
    
    # Product management
    add_product_select_position = State()
    add_product_content = State()
    delete_product_id = State()
    
    # Helper management
    add_helper = State()
    remove_helper = State()

# User states
class UserStates(StatesGroup):
    # Purchase states
    select_category = State()
    select_position = State()
    confirm_purchase = State()
    
    # Balance top-up states
    select_payment_method = State()
    enter_amount = State()
    confirm_payment = State()
    enter_crypto_amount = State()  # New state for crypto amount
    
    # Support states
    write_support_message = State()


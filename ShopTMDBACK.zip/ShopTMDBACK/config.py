import os

BOT_TOKEN = '77427378:AAG3uWZONTu55oknturj49tpwRx'


ADMIN_IDS = [] 

HELPER_IDS = [] 

# Database settings
DB_FOLDER = "database"
USERS_DB = os.path.join(DB_FOLDER, "users.json")
CATEGORIES_DB = os.path.join(DB_FOLDER, "categories.json")
POSITIONS_DB = os.path.join(DB_FOLDER, "positions.json")
PRODUCTS_DB = os.path.join(DB_FOLDER, "products.json")
RECEIPTS_DB = os.path.join(DB_FOLDER, "receipts.json")
SETTINGS_DB = os.path.join(DB_FOLDER, "settings.json")
STATS_DB = os.path.join(DB_FOLDER, "stats.json")
TRANSACTIONS_DB = os.path.join(DB_FOLDER, "transactions.json")
INVOICES_DB = os.path.join(DB_FOLDER, "invoices.json")

# Default settings
DEFAULT_SETTINGS = {
    "faq": "Здесь будет FAQ",
    "support_id": None,
    "maintenance_mode": False,
    "purchases_enabled": True,
    "topup_enabled": True,
    "crypto_bot_token": None,
    "payment_methods": ["crypto"],
    "anti_spam": {
        "enabled": True,
        "rate_limit": 10,
        "rate_period": 3
    },
    "helpers": []  # Store helper IDs here
}

# Default stats
DEFAULT_STATS = {
    "total_users": 0,
    "total_purchases": 0,
    "total_topups": 0,
    "total_products_sold": 0,
    "total_revenue": 0,
    "total_user_balance": 0
}

# Load helpers from settings
def load_helpers_from_settings():
    import json
    if os.path.exists(SETTINGS_DB):
        try:
            with open(SETTINGS_DB, 'r', encoding='utf-8') as f:
                settings = json.load(f)
                if "helpers" in settings:
                    global HELPER_IDS
                    HELPER_IDS = settings["helpers"]
        except Exception as e:
            import logging
            logging.error(f"Error loading helpers from settings: {e}")

# Load helpers when config is imported
load_helpers_from_settings()
import json
import os
import logging
import uuid
import requests
from datetime import datetime
from config import (
    DB_FOLDER, USERS_DB, CATEGORIES_DB, POSITIONS_DB, 
    PRODUCTS_DB, RECEIPTS_DB, SETTINGS_DB, STATS_DB,
    TRANSACTIONS_DB, INVOICES_DB, DEFAULT_SETTINGS, DEFAULT_STATS,
)
# Ensure database directory exists
os.makedirs(DB_FOLDER, exist_ok=True)

class Database:
    def __init__(self):
        self.users = self._load_data(USERS_DB, {})
        self.categories = self._load_data(CATEGORIES_DB, {})
        self.positions = self._load_data(POSITIONS_DB, {})
        self.products = self._load_data(PRODUCTS_DB, {})
        self.receipts = self._load_data(RECEIPTS_DB, {})
        self.settings = self._load_data(SETTINGS_DB, DEFAULT_SETTINGS)
        self.stats = self._load_data(STATS_DB, DEFAULT_STATS)
        self.transactions = self._load_data(TRANSACTIONS_DB, {})
        self.invoices = self._load_data(INVOICES_DB, {})
    
    def _load_data(self, file_path, default_data):
        """Load data from a JSON file or return default if file doesn't exist"""
        try:
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return default_data
        except Exception as e:
            logging.error(f"Error loading data from {file_path}: {e}")
            return default_data
    
    def _save_data(self, file_path, data):
        """Save data to a JSON file"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            return True
        except Exception as e:
            logging.error(f"Error saving data to {file_path}: {e}")
            return False
    
    def save(self):
        """Save all data to respective files"""
        self._save_data(USERS_DB, self.users)
        self._save_data(CATEGORIES_DB, self.categories)
        self._save_data(POSITIONS_DB, self.positions)
        self._save_data(PRODUCTS_DB, self.products)
        self._save_data(RECEIPTS_DB, self.receipts)
        self._save_data(SETTINGS_DB, self.settings)
        self._save_data(STATS_DB, self.stats)
        self._save_data(TRANSACTIONS_DB, self.transactions)
        self._save_data(INVOICES_DB, self.invoices)
        logging.info("Database saved")
    
    def register_user(self, user_id, username, first_name):
        """Register a new user if not exists"""
        if str(user_id) not in self.users:
            self.users[str(user_id)] = {
                "id": user_id,
                "username": username,
                "first_name": first_name,
                "balance": 0.0,
                "purchases": [],
                "join_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "last_activity": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            self.stats["total_users"] += 1
            self.save()
            return True
        return False
    
    def update_user_activity(self, user_id):
        """Update user's last activity timestamp"""
        if str(user_id) in self.users:
            self.users[str(user_id)]["last_activity"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return True
        return False
    
    def generate_receipt_id(self):
        """Generate a unique receipt ID"""
        return f"R{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    def generate_transaction_id(self):
        """Generate a unique transaction ID"""
        return str(uuid.uuid4())
    
    def create_transaction(self, user_id, amount, transaction_type, payment_method=None):
        """
        Create a new transaction
        Returns transaction ID if successful, None otherwise
        """
        transaction_id = self.generate_transaction_id()
        
        self.transactions[transaction_id] = {
            "id": transaction_id,
            "user_id": user_id,
            "amount": amount,
            "type": transaction_type,
            "payment_method": payment_method,
            "status": "pending",
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "completed_at": None
        }
        
        self.save()
        return transaction_id
    
    def complete_transaction(self, transaction_id):
        """
        Mark a transaction as completed
        Returns True if successful, False otherwise
        """
        if transaction_id not in self.transactions:
            return False
        
        if self.transactions[transaction_id]["status"] != "pending":
            return False
        
        self.transactions[transaction_id]["status"] = "completed"
        self.transactions[transaction_id]["completed_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Process the transaction
        user_id = str(self.transactions[transaction_id]["user_id"])
        amount = self.transactions[transaction_id]["amount"]
        transaction_type = self.transactions[transaction_id]["type"]
        
        if transaction_type == "topup":
            # Add balance to user
            self.users[user_id]["balance"] += amount
            self.stats["total_topups"] += 1
            self.stats["total_user_balance"] += amount
        
        self.save()
        return True
    
    def cancel_transaction(self, transaction_id):
        """
        Mark a transaction as cancelled
        Returns True if successful, False otherwise
        """
        if transaction_id not in self.transactions:
            return False
        
        if self.transactions[transaction_id]["status"] != "pending":
            return False
        
        self.transactions[transaction_id]["status"] = "cancelled"
        self.save()
        return True
    
    def is_transaction_completed(self, transaction_id):
        """Check if a transaction is completed"""
        if transaction_id not in self.transactions:
            return False
        
        return self.transactions[transaction_id]["status"] == "completed"
    
# In database.py

    def create_crypto_invoice(self, user_id, amount_usdt):
        """Create a new invoice via Crypto Bot API"""
        try:
            # Get token from settings
            token = self.settings.get("crypto_bot_token")
            
            # If token is not set in settings, use the default from config (if available)
            if not token and 'CRYPTO_BOT_TOKEN' in globals():
                token = self.settings.get("crypto_bot_token")
                
            if not token:
                logging.error("Crypto Bot token is not set")
                return None
                
            # Create invoice via Crypto Bot API
            headers = {
                'Crypto-Pay-API-Token': token,
                'Content-Type': 'application/json'
            }
            
            payload = {
                'asset': 'USDT',
                'amount': str(amount_usdt),
                'description': f'Top-up for user {user_id}',
                'hidden_message': f'User ID: {user_id}',
                'paid_btn_name': 'openBot',
                'paid_btn_url': f'https://t.me/@DeXXeled_Shop_Bot'
            }
            
            response = requests.post(
                'https://pay.crypt.bot/api/createInvoice',
                headers=headers,
                json=payload
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('ok'):
                    # Log the full response to see what keys are available
                    logging.info(f"Crypto Bot API response: {data}")
                    return data.get('result')
            
            logging.error(f"Failed to create Crypto Bot invoice: {response.text}")
            return None
        except Exception as e:
            logging.error(f"Failed to create Crypto Bot invoice: {e}")
            return None

    def check_invoice_status(self, invoice_id):
        """Check the status of an invoice via Crypto Bot API"""
        try:
            # Get token from settings
            token = self.settings.get("crypto_bot_token")
            
            # If token is not set in settings, use the default from config (if available)
            if not token and 'CRYPTO_BOT_TOKEN' in globals():
                token = self.settings.get("crypto_bot_token")
                
            if not token:
                logging.error("Crypto Bot token is not set")
                return None
                
            # Check invoice via Crypto Bot API
            headers = {
                'Crypto-Pay-API-Token': token,
                'Content-Type': 'application/json'
            }
            
            # The correct endpoint is getInvoices, not getInvoice
            response = requests.get(
                f'https://pay.crypt.bot/api/getInvoices?invoice_ids={invoice_id}',
                headers=headers
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('ok'):
                    # Log the full response to see what keys are available
                    logging.info(f"Crypto Bot API response for invoice check: {data}")
                    
                    # The result is a list of invoices, so we need to get the first one
                    invoices = data.get('result', {}).get('items', [])
                    if invoices:
                        return invoices[0]
                    else:
                        logging.error(f"No invoices found with ID {invoice_id}")
                        return None
            
            logging.error(f"Failed to check Crypto Bot invoice: {response.text}")
            return None
        except Exception as e:
            logging.error(f"Failed to check Crypto Bot invoice: {e}")
            return None

# Initialize database
db = Database()

# Helper functions
def is_admin(user_id):
    """Check if user is an admin"""
    from config import ADMIN_IDS
    return user_id in ADMIN_IDS

def is_helper(user_id):
    """Check if user is a helper"""
    from config import HELPER_IDS
    return user_id in HELPER_IDS

def is_admin_or_helper(user_id):
    """Check if user is an admin or helper"""
    return is_admin(user_id) or is_helper(user_id)

def format_currency(amount):
    """Format currency amount"""
    return f"${amount:.2f}"

